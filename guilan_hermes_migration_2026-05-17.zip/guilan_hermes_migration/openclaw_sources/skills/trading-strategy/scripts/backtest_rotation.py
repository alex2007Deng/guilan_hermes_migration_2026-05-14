#!/usr/bin/env python3
"""
归澜 v1.4 完整多股票轮动回测
S.C.R.E.E.N. + S-Sector 2.0 赛道分级 + 每周精选池 + 3股持仓轮换
回测区间: 2023-11 ~ 2026-05 (约2.5年)
"""

import json
from typing import Dict, List, Optional, Tuple
from collections import defaultdict

# ===================== 加载全部数据 =====================
with open('/tmp/backtest_v14_data.json') as f:
    d1 = json.load(f)
with open('/tmp/backtest_rotation_extra.json') as f:
    d2 = json.load(f)
with open('/tmp/backtest_v14_sectors.json') as f:
    sector_raw = json.load(f)

all_stock_data = {**d1, **d2}

def parse(datalist):
    recs = []
    for r in datalist:
        recs.append({
            'date': r['date'], 'close': float(r.get('close',0)),
            'open': float(r.get('open',0)), 'high': float(r.get('max',0)),
            'low': float(r.get('min',0)), 'pct': float(r.get('priceChangePct',0)),
            'vol': float(str(r.get('vol','0')).replace('亿','e4').replace('万','').replace('e4','0000')),
            'ampl': float(r.get('amplitude',0)), 'amount': float(str(r.get('amount','0')).replace('万亿','e8').replace('亿','e4').replace('万','').replace('e4','0000')[:15] or '0'),
        })
    recs.sort(key=lambda x: x['date'])
    return recs

stocks = {}
for k, v in all_stock_data.items():
    code = k.split('_')[0]
    name = k.split('_', 1)[1]
    stocks[code] = {'name': name, 'records': parse(v)}

sectors = {}
for k, v in sector_raw.items():
    sname = k.split('_', 1)[1]
    sectors[sname] = parse(v)

# ===================== S-Sector 2.0 赛道分级 =====================
SECTOR_GRADE = {
    # 🥇 黄金: 半导体设备、芯片设计、AI
    '002371': ('半导体', 'gold', '半导体设备'),
    '002049': ('芯片', 'gold', '芯片设计'),
    '603501': ('芯片', 'gold', 'CIS传感器'),
    '002415': ('芯片', 'gold', 'AI视觉'),
    '300661': ('芯片', 'gold', '模拟芯片'),
    '688012': ('半导体', 'gold', '半导体设备'),
    '603986': ('芯片', 'gold', '芯片设计'),
    # 🥈 白银
    '300750': ('芯片', 'silver', '新能源电池'),  # 用芯片板块近似
    # 🥉 青铜
    '601012': ('芯片', 'bronze', '光伏组件'),   # 产能过剩
    # ⛔ 黑名单
    '600584': ('先进封装', 'blacklist', '封测代工'),
    '002156': ('先进封装', 'blacklist', '封测代工'),
}

# Blacklist stocks are never considered
BLACKLIST = {code for code, (_, grade, _) in SECTOR_GRADE.items() if grade == 'blacklist'}

# ===================== Helper Functions =====================
def ma(d, n, i):
    if i < n-1 or len(d) <= i: return None
    return sum(d[j]['close'] for j in range(i-n+1, i+1)) / n

def avg_ampl(d, n, i):
    if i < n-1 or len(d) <= i: return None
    return sum(d[j]['ampl'] for j in range(i-n+1, i+1)) / n

def avg_vol(d, n, i):
    if i < n-1 or len(d) <= i: return None
    return sum(d[j]['vol'] for j in range(i-n+1, i+1)) / n

def ret_n(d, n, i):
    """Return over last n days"""
    if i < n: return None
    return (d[i]['close'] - d[i-n]['close']) / d[i-n]['close'] * 100

def di(d, date):
    for i, r in enumerate(d):
        if r['date'] == date: return i
    return -1

def count_beat(ds, db, n, i):
    c = 0
    for j in range(max(0,i-n+1), i+1):
        b = di(db, ds[j]['date'])
        if b >= 0 and ds[j]['pct'] >= db[b]['pct']: c += 1
    return c

def sector_days_available(ds, db, n, i):
    c = 0
    for j in range(max(0,i-n+1), i+1):
        if di(db, ds[j]['date']) >= 0: c += 1
    return c

# ===================== S.C.R.E.E.N. + S-Sector 2.0 筛选 =====================
def screen_stock(code, i, min_date=None):
    """
    Run full S.C.R.E.E.N. + S-Sector 2.0 filter.
    Returns (pass, score, reasons) or (False, 0, reasons) if failed.
    Score is used for ranking within the selected pool.
    """
    data = stocks[code]['records']
    if i < 60 or i >= len(data):
        return False, 0, ["数据不足"]
    
    r = data[i]
    sector_name, grade, sub_sector = SECTOR_GRADE.get(code, ('芯片', 'bronze', '未知'))
    sector = sectors.get(sector_name)
    
    reasons = []
    score = 0
    
    # ⛔ Blacklist auto-exclude
    if code in BLACKLIST:
        return False, 0, [f"⛔ 赛道黑名单: {sub_sector}"]
    
    # 📊 E-Elasticity: 20-day avg amplitude >= 3.5%
    ampl = avg_ampl(data, 20, i)
    if ampl is None or ampl < 3.5:
        reasons.append(f"振幅{ampl:.1f}%<3.5%")
        return False, 0, reasons
    score += ampl * 3  # Weight: 40%
    
    # 📊 R-Range: MA20/MA60 direction
    m20 = ma(data, 20, i)
    m60 = ma(data, 60, i)
    if m20 is None:
        reasons.append("MA20未形成")
        return False, 0, reasons
    m20_prev = ma(data, 20, i-5) if i >= 5 else m20
    if m20_prev and m20 >= m20_prev:
        score += 10
    else:
        reasons.append("MA20下行")
        return False, 0, reasons
    
    if m60:
        m60_prev = ma(data, 60, i-5) if i >= 5 else m60
        if m60_prev and m60 >= m60_prev:
            score += 5
    
    # 📊 S-Sector 2.0: Grade bonus + relative strength
    grade_bonus = {'gold': 20, 'silver': 12, 'bronze': 5}
    score += grade_bonus.get(grade, 0)
    
    if sector:
        beat10 = count_beat(data, sector, 10, i)
        beat5 = count_beat(data, sector, 5, i)
        avail10 = sector_days_available(data, sector, 10, i)
        
        if avail10 >= 8 and beat10 < 5:
            reasons.append(f"近10日跑输板块({beat10}/{avail10})")
            return False, 0, reasons
        
        score += beat5 * 2  # Weight for relative strength
        score += beat10 * 1
    
    # 📊 C-Category: Qualitative (skip in backtest)
    # 📊 E-Earnings: Qualitative (skip in backtest)
    # 📊 N-Noise: Qualitative (skip in backtest)
    
    # Recent momentum bonus
    ret5 = ret_n(data, 5, i)
    ret20 = ret_n(data, 20, i)
    if ret5: score += ret5 * 0.5
    if ret20: score += ret20 * 0.3
    
    return True, score, [f"{grade}|振幅{ampl:.1f}%|RS{beat5}/5|评分{score:.0f}"]

# ===================== 归澜轮动引擎 =====================
class GuilunRotation:
    def __init__(self, capital=100000):
        self.capital = capital
        self.cash = capital
        self.positions = {}    # code -> {'shares': N, 'entry_price': P, 'entry_date': D, 'entry_idx': I}
        self.trades = []
        self.equities = []
        self.max_positions = 3
        self.rebalance_interval = 5  # Every 5 trading days (~weekly)
        
    def get_equity(self, date_idx_map):
        """Calculate total equity"""
        eq = self.cash
        for code, pos in self.positions.items():
            data = stocks[code]['records']
            idx = self._find_idx(data, date_idx_map)
            if idx >= 0:
                eq += pos['shares'] * data[idx]['close']
        return eq
    
    def _find_idx(self, data, date_idx_map):
        """Find the index of the latest common date"""
        # Use the last data point
        return len(data) - 1
    
    def screen_pool(self, date, idx_map):
        """Run weekly screening and return ranked selected pool"""
        candidates = []
        for code in stocks:
            if code in BLACKLIST:
                continue
            i = idx_map.get(code)
            if i is None:
                continue
            passed, score, reasons = screen_stock(code, i)
            if passed:
                candidates.append((code, score, reasons))
        
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[:8]  # Top 8 → 精选池
    
    def check_exit_signals(self, code, i, date):
        """Check if a position should be exited. Returns (should_exit, reason, fraction)"""
        if code not in self.positions:
            return False, '', 0
        
        pos = self.positions[code]
        data = stocks[code]['records']
        r = data[i]
        pnl = (r['close'] - pos['entry_price']) / pos['entry_price'] * 100
        
        # Stop loss -5%
        if pnl <= -5:
            return True, f"止损-5%({pnl:.1f}%)", 1.0
        
        # MA60 break → full exit
        m60 = ma(data, 60, i)
        if m60 and r['close'] < m60:
            return True, f"破MA60({m60:.1f})", 1.0
        
        # Take profit +8% → sell half
        if pnl >= 8:
            return True, f"止盈+{pnl:.1f}%", 0.5
        
        # MA20 break → sell half
        m20 = ma(data, 20, i)
        if m20 and r['close'] < m20 and data[i-1]['close'] >= m20:
            return True, f"破MA20({m20:.1f})", 0.5
        
        # Sector underperformance
        sector_name, _, _ = SECTOR_GRADE.get(code, ('芯片', 'bronze', ''))
        sector = sectors.get(sector_name)
        if sector:
            si = di(sector, r['date'])
            if si >= 0:
                sp = sector[si]['pct']
                if sp > 2 and r['pct'] < 1:
                    return True, f"板块大涨{sp:.1f}%vs个股{r['pct']:.1f}%", 0.5
        
        # Time stop: 7 days no profit
        if i - pos['entry_idx'] >= 7 and pnl < -1:
            return True, f"时间止损({i-pos['entry_idx']}天,{pnl:.1f}%)", 0.5
        
        return False, '', 0
    
    def check_entry_signals(self, code, i, date):
        """Check 三道闸门 for entry. Returns (should_enter, signals_count)"""
        data = stocks[code]['records']
        r = data[i]
        signals = []
        
        sector_name, _, _ = SECTOR_GRADE.get(code, ('芯片', 'bronze', ''))
        sector = sectors.get(sector_name)
        
        # Gate 2: Sector
        if sector:
            si = di(sector, r['date'])
            if si >= 0 and sector[si]['pct'] > -0.5:
                signals.append("板块OK")
                if r['pct'] >= sector[si]['pct'] * 0.8:
                    signals.append("跟涨板块")
        
        # Gate 3a: Volume contraction
        vol5 = avg_vol(data, 5, i)
        if vol5 and r['vol'] < vol5 * 0.9:
            signals.append("缩量")
        
        # Gate 3b: Price near MA20
        m20 = ma(data, 20, i)
        if m20 and 0 <= (r['close'] - m20) / m20 * 100 <= 4:
            signals.append("近MA20")
        
        # Gate 3c: Pullback but closing OK
        if r['pct'] < 0.5 and r['close'] > r['low'] * 1.01:
            signals.append("尾盘企稳")
        
        # Gate 3d: MA20 trending up
        if m20:
            m20_5 = ma(data, 20, i-5) if i >= 5 else m20
            if m20_5 and m20 >= m20_5:
                signals.append("MA20向上")
        
        # Gate 3e: Above MA60
        m60 = ma(data, 60, i)
        if m60 and r['close'] > m60:
            signals.append("站上MA60")
        
        return len(signals) >= 3, len(signals)
    
    def execute_sell(self, code, i, reason, fraction):
        """Execute a sell (partial or full)"""
        pos = self.positions[code]
        data = stocks[code]['records']
        r = data[i]
        sell_shares = pos['shares'] * fraction
        pnl_pct = (r['close'] - pos['entry_price']) / pos['entry_price'] * 100
        pnl_amt = (r['close'] - pos['entry_price']) * sell_shares
        
        self.trades.append({
            'code': code, 'name': stocks[code]['name'],
            'entry_date': pos['entry_date'], 'exit_date': r['date'],
            'entry_price': pos['entry_price'], 'exit_price': r['close'],
            'pnl_pct': pnl_pct, 'pnl_amt': pnl_amt,
            'shares': sell_shares, 'reason': reason, 'type': 'SELL'
        })
        
        self.cash += sell_shares * r['close']
        pos['shares'] -= sell_shares
        
        if pos['shares'] < 1 or fraction >= 1.0:
            del self.positions[code]
            return True  # Fully exited
        return False  # Partial, still holding
    
    def execute_buy(self, code, i, score, signals_n):
        """Execute a buy"""
        data = stocks[code]['records']
        r = data[i]
        buy_amount = self.cash / max(1, self.max_positions - len(self.positions) + 1)
        buy_amount = min(buy_amount, self.cash * 0.4)  # Max 40% per position
        shares = buy_amount / r['close']
        
        self.positions[code] = {
            'shares': shares,
            'entry_price': r['close'],
            'entry_date': r['date'],
            'entry_idx': i,
            'score': score
        }
        self.cash -= buy_amount
        
        self.trades.append({
            'code': code, 'name': stocks[code]['name'],
            'entry_date': r['date'], 'exit_date': '',
            'entry_price': r['close'], 'exit_price': 0,
            'pnl_pct': 0, 'pnl_amt': 0,
            'shares': shares, 'reason': f"BUY|评分{score:.0f}|{signals_n}信号",
            'type': 'BUY'
        })

# ===================== Run Backtest =====================
print("=" * 80)
print("📊 归澜 v1.4 完整轮动回测")
print("S.C.R.E.E.N. + S-Sector 2.0 + 每周精选池 + 3股持仓轮换")
print("=" * 80)

# First, find the common date range and align all stocks
all_dates = set()
for code in stocks:
    for r in stocks[code]['records']:
        all_dates.add(r['date'])
all_dates = sorted(all_dates)

# Find start: when at least 5 stocks have 60+ days of data
start_date = None
for date in all_dates:
    count = 0
    for code in stocks:
        idx = di(stocks[code]['records'], date)
        if idx >= 60:
            count += 1
    if count >= 5:
        start_date = date
        break

print(f"回测起点: {start_date}")

# Build trading calendar
trading_dates = []
for date in all_dates:
    if date >= start_date:
        trading_dates.append(date)

print(f"交易天数: {len(trading_dates)}")

# Initialize
engine = GuilunRotation(100000)
rebalance_counter = 0
current_pool = []  # Current selected pool

# Pre-build index maps for speed
idx_cache = {}
for code in stocks:
    data = stocks[code]['records']
    idx_cache[code] = {}
    for i, r in enumerate(data):
        idx_cache[code][r['date']] = i

for di_t in range(len(trading_dates)):
    date = trading_dates[di_t]
    rebalance_day = (rebalance_counter >= engine.rebalance_interval)
    
    # Get current indices for all stocks
    current_idx = {}
    for code in stocks:
        current_idx[code] = idx_cache[code].get(date, -1)
    
    # ============ 1. Handle exits (every day) ============
    exit_codes = []
    for code in list(engine.positions.keys()):
        i = current_idx.get(code, -1)
        if i < 0:
            continue
        should_exit, reason, fraction = engine.check_exit_signals(code, i, date)
        if should_exit:
            fully_exited = engine.execute_sell(code, i, reason, fraction)
            if fully_exited:
                exit_codes.append(code)
    
    # ============ 2. Weekly rebalance ============
    if rebalance_day:
        # Re-screen the entire pool
        new_pool = engine.screen_pool(date, current_idx)
        current_pool = new_pool
        rebalance_counter = 0
        
        # Determine rotation: should we swap any positions?
        # Keep current positions that are still in top 5 of pool
        pool_codes = {c for c, _, _ in current_pool[:5]}
        
        # Exit positions that fell out of top 5
        for code in list(engine.positions.keys()):
            if code not in pool_codes and code not in exit_codes:
                i = current_idx.get(code, -1)
                if i >= 0:
                    engine.execute_sell(code, i, "跌出精选池前5", 1.0)
    
    # ============ 3. Enter new positions ============
    if engine.cash > 5000 and len(engine.positions) < engine.max_positions:
        # Try to enter top-ranked stocks from the pool that we don't hold
        for code, score, reasons in (current_pool if current_pool else []):
            if code in engine.positions:
                continue
            if len(engine.positions) >= engine.max_positions:
                break
            
            i = current_idx.get(code, -1)
            if i < 0:
                continue
            
            should_enter, signals_n = engine.check_entry_signals(code, i, date)
            if should_enter:
                engine.execute_buy(code, i, score, signals_n)
    
    # ============ 4. Track equity ============
    eq = engine.cash
    for code, pos in engine.positions.items():
        i = current_idx.get(code, -1)
        if i >= 0:
            eq += pos['shares'] * stocks[code]['records'][i]['close']
    engine.equities.append((date, eq))
    
    rebalance_counter += 1

# Close all positions at end
for code in list(engine.positions.keys()):
    data = stocks[code]['records']
    r = data[-1]
    pos = engine.positions[code]
    pnl = (r['close'] - pos['entry_price']) / pos['entry_price'] * 100
    engine.trades.append({
        'code': code, 'name': stocks[code]['name'],
        'entry_date': pos['entry_date'], 'exit_date': r['date'],
        'entry_price': pos['entry_price'], 'exit_price': r['close'],
        'pnl_pct': pnl, 'pnl_amt': (r['close']-pos['entry_price'])*pos['shares'],
        'shares': pos['shares'], 'reason': '期末平仓', 'type': 'SELL'
    })
    engine.cash += pos['shares'] * r['close']
engine.positions = {}

# ===================== Results =====================
final_eq = engine.equities[-1][1] if engine.equities else engine.cash
total_ret = (final_eq - 100000) / 100000 * 100

# B&H benchmark: equal weight portfolio
bh_values = []
for date, _ in engine.equities:
    bh_eq = 0
    count = 0
    for code in stocks:
        if code in BLACKLIST:
            continue
        sidx = idx_cache[code].get(date, -1)
        if sidx >= 60:
            data = stocks[code]['records']
            # Initial investment: equal split at start
            start_idx = idx_cache[code].get(trading_dates[0], -1)
            if start_idx >= 0:
                start_price = data[start_idx]['close']
                if start_price > 0:
                    bh_eq += data[sidx]['close'] / start_price
                    count += 1
    if count > 0:
        bh_values.append(bh_eq / count * 100000)
    else:
        bh_values.append(bh_values[-1] if bh_values else 100000)

bh_ret = (bh_values[-1] - 100000) / 100000 * 100 if bh_values else 0

# Trade stats
exits = [t for t in engine.trades if t['type'] == 'SELL']
wins = [t for t in exits if t['pnl_pct'] > 0]
losses = [t for t in exits if t['pnl_pct'] <= 0]
wr = len(wins) / len(exits) * 100 if exits else 0
aw = sum(t['pnl_pct'] for t in wins) / len(wins) if wins else 0
al = sum(t['pnl_pct'] for t in losses) / len(losses) if losses else 0

# Max drawdown
peak = 100000
max_dd = 0
for _, eq in engine.equities:
    if eq > peak: peak = eq
    dd = (peak - eq) / peak * 100
    if dd > max_dd: max_dd = dd

# Trade by stock
trades_by_stock = defaultdict(lambda: {'wins': 0, 'losses': 0, 'total_pnl': 0})
for t in exits:
    code = t['code']
    if t['pnl_pct'] > 0:
        trades_by_stock[code]['wins'] += 1
    else:
        trades_by_stock[code]['losses'] += 1
    trades_by_stock[code]['total_pnl'] += t['pnl_amt']

# ===================== Print Results =====================
print(f"\n{'='*80}")
print("📊 归澜轮动回测结果")
print(f"{'='*80}")
print(f"初始资金: 100,000元")
print(f"最终资金: {final_eq:,.0f}元")
print(f"策略收益: {total_ret:+.2f}%")
print(f"买入持有: {bh_ret:+.2f}% (等权组合,排除黑名单)")
print(f"相对超额: {total_ret - bh_ret:+.2f}%")
print(f"最大回撤: {max_dd:.2f}%")
print(f"胜率: {wr:.0f}% ({len(wins)}胜{len(losses)}负, 共{len(exits)}笔退出)")
print(f"均盈: +{aw:.2f}% | 均亏: {al:.2f}%")
if aw > 0 and abs(al) > 0:
    print(f"盈亏比: {aw/abs(al):.2f}")

print(f"\n--- 各股票交易统计 ---")
print(f"{'股票':<16} {'盈利':>6} {'亏损':>6} {'净盈亏':>10}")
print("-" * 44)
for code in sorted(trades_by_stock.keys(), key=lambda c: trades_by_stock[c]['total_pnl'], reverse=True):
    ts = trades_by_stock[code]
    name = stocks[code]['name']
    print(f"{name:<10}({code}) {ts['wins']:>4}胜 {ts['losses']:>4}负 {ts['total_pnl']:>+8.0f}元")

print(f"\n--- 最近10笔交易 ---")
for t in exits[-10:]:
    emoji = "✅" if t['pnl_pct'] > 0 else "❌"
    print(f"  {emoji} {t['name']}({t['code']}) {t['entry_date']}→{t['exit_date']}: "
          f"{t['entry_price']:.2f}→{t['exit_price']:.2f} {t['pnl_pct']:+.2f}% "
          f"({t['pnl_amt']:+.0f}元) [{t['reason']}]")

print(f"\n--- 当前精选池 (最终) ---")
for code, score, reasons in (current_pool[:5] if current_pool else []):
    name = stocks[code]['name']
    grade = SECTOR_GRADE.get(code, ('?','?','?'))[1]
    print(f"  {'🥇' if grade=='gold' else '🥈' if grade=='silver' else '🥉'} {name}({code}) 评分{score:.0f} | {'|'.join(reasons)}")

print(f"\n⚠️ 风险提示: 历史回测不代表未来表现")

# ===================== Comparison with single-stock =====================
print(f"\n{'='*80}")
print("📊 轮动 vs 单股持有 对比")
print(f"{'='*80}")
print(f"{'策略':<25} {'收益':>10} {'回撤':>8} {'胜率':>6}")
print("-" * 55)
print(f"{'归澜轮动 (11股全池)':<25} {total_ret:>+8.2f}% {max_dd:>6.2f}% {wr:>4.0f}%")

# Calculate per-stock B&H for comparison
for code in ['603986', '002371', '002049', '603501', '002415', '300750', '300661', '688012', '601012']:
    if code in stocks:
        data = stocks[code]['records']
        start_idx = idx_cache[code].get(trading_dates[0], -1)
        if start_idx >= 0 and len(data) > 0:
            s_ret = (data[-1]['close'] - data[start_idx]['close']) / data[start_idx]['close'] * 100
            name = stocks[code]['name']
            print(f"{name:<10}({code}) B&H{'':<11} {s_ret:>+8.2f}%")

#!/usr/bin/env python3
"""
600584 长电科技 3个月策略回测
策略：均值回归 + 趋势确认
回测区间：2026-01-27 至 2026-04-29（约60个交易日）
"""

import json, sys

# 数据格式: date|close|open|high|low|pctChange|vol|amplitude
raw = """20260429|44.36|44.20|44.63|43.09|-1.64|8628.76万|3.41
20260428|45.10|46.10|46.49|44.76|-2.63|8044.00万|3.73
20260427|46.32|46.00|46.95|45.55|3.19|1.02亿|3.12
20260424|44.89|44.82|45.87|44.51|1.08|7002.90万|3.06
20260423|44.41|45.56|45.78|44.04|-2.42|6631.56万|3.82
20260422|45.51|43.84|45.68|43.77|3.36|7686.14万|4.34
20260421|44.03|44.50|44.60|43.13|-1.03|4651.16万|3.30
20260420|44.49|44.00|45.00|43.49|1.16|6118.08万|3.43
20260417|43.98|43.68|44.60|43.25|0.57|6139.42万|3.09
20260416|43.73|43.60|44.02|43.20|0.32|4424.33万|1.88
20260415|43.59|44.50|44.70|43.36|-1.69|6806.66万|3.02
20260414|44.34|43.60|45.08|43.30|3.48|8255.00万|4.15
20260413|42.85|42.50|43.50|42.50|-0.40|4432.11万|2.32
20260410|43.02|42.74|43.79|42.74|2.65|6676.69万|2.51
20260409|41.91|41.17|42.47|41.05|-0.17|4975.33万|3.38
20260408|41.98|40.05|41.98|40.03|8.14|7137.12万|5.02
20260407|38.82|38.70|39.06|38.54|1.38|2738.21万|1.36
20260403|38.29|38.88|38.98|38.02|-0.49|2617.06万|2.49
20260402|38.48|39.53|39.53|38.28|-2.56|3289.15万|3.17
20260401|39.49|39.88|39.89|39.24|1.91|3670.70万|1.68
20260331|38.75|39.50|39.60|38.55|-2.74|4040.05万|2.64
20260330|39.84|38.66|39.97|38.45|0.78|3388.91万|3.85
20260327|39.53|38.85|39.94|38.60|0.25|3679.40万|3.40
20260326|39.43|40.40|40.76|39.24|-2.98|3777.49万|3.74
20260325|40.64|39.90|41.26|39.87|3.02|5332.89万|3.52
20260324|39.45|39.90|39.97|38.39|0.95|4611.81万|4.04
20260323|39.08|40.48|41.18|38.67|-7.02|7571.04万|5.97
20260320|42.03|44.66|44.75|42.00|-4.89|7728.24万|6.22
20260319|44.19|44.79|45.17|44.00|-3.45|5319.42万|2.56
20260318|45.77|44.25|46.17|43.93|4.62|7912.33万|5.12
20260317|43.75|46.03|46.04|43.69|-4.37|6211.14万|5.14
20260316|45.75|45.31|46.46|44.15|0.59|7052.71万|5.08
20260313|45.48|45.27|46.80|44.79|-0.55|5430.64万|4.40
20260312|45.73|46.60|47.68|45.44|-2.31|6535.74万|4.79
20260311|46.81|46.46|48.26|46.33|1.76|9178.79万|4.20
20260310|46.00|46.00|46.60|45.35|2.22|7132.16万|2.78
20260309|45.00|45.63|45.63|42.70|-4.34|1.08亿|6.23
20260306|47.04|48.10|49.09|46.86|-3.41|9202.53万|4.58
20260305|48.70|49.30|50.33|48.22|1.76|1.15亿|4.41
20260304|47.86|45.91|49.45|45.91|0.61|9952.65万|7.44
20260303|47.57|47.30|49.89|46.94|1.71|1.56亿|6.31
20260302|46.77|46.78|47.68|46.70|-2.89|6362.64万|2.03
20260227|48.16|47.76|48.24|46.31|-1.15|8175.47万|3.96
20260226|48.72|46.90|49.98|46.60|3.84|1.01亿|7.20
20260225|46.92|47.45|47.63|45.40|0.39|8384.68万|4.77
20260224|46.74|46.90|47.42|46.05|1.32|5510.07万|2.97
20260213|46.13|46.00|46.97|45.80|-1.07|4314.39万|2.51
20260212|46.63|46.50|46.97|46.19|0.95|4827.48万|1.69
20260211|46.19|45.86|46.86|45.80|-0.11|3391.48万|2.29
20260210|46.24|46.77|47.49|46.10|-1.11|4447.34万|2.97
20260209|46.76|45.20|46.96|44.50|6.13|7734.54万|5.58
20260206|44.06|43.99|44.68|43.50|-1.34|4864.68万|2.64
20260205|44.66|44.88|45.09|43.87|-2.64|6470.76万|2.66
20260204|45.87|46.99|47.13|45.40|-3.82|6984.46万|3.63
20260203|47.69|47.45|47.82|46.84|2.91|6426.56万|2.11
20260202|46.34|48.44|48.75|46.21|-6.35|9566.48万|5.13
20260130|49.48|48.95|50.14|47.90|1.02|9234.20万|4.57
20260129|48.98|49.40|51.00|48.80|-2.14|9032.31万|4.40
20260128|50.05|49.26|51.40|49.19|3.84|1.51亿|4.59
20260127|48.20|47.18|48.66|46.15|1.88|1.30亿|5.31"""

def parse_vol(v):
    if '亿' in v:
        return float(v.replace('亿','')) * 10000
    elif '万' in v:
        return float(v.replace('万',''))
    return float(v)

# Parse data (chronological order)
records = []
for line in raw.strip().split('\n'):
    parts = line.split('|')
    records.append({
        'date': parts[0],
        'close': float(parts[1]),
        'open': float(parts[2]),
        'high': float(parts[3]),
        'low': float(parts[4]),
        'pct': float(parts[5]),
        'vol': parse_vol(parts[6]),
        'ampl': float(parts[7])
    })

records.sort(key=lambda r: r['date'])  # chronological

def ma(data, n, i):
    """n-day MA at index i"""
    if i < n-1:
        return None
    return sum(data[j]['close'] for j in range(i-n+1, i+1)) / n

def avg_vol(data, n, i):
    """n-day average volume"""
    if i < n-1:
        return None
    return sum(data[j]['vol'] for j in range(i-n+1, i+1)) / n

# ============ BACKTEST ============
print("=" * 70)
print("600584 长电科技 均值回归策略回测")
print("回测区间: 2026-01-27 ~ 2026-04-29")
print("=" * 70)

capital = 100000.0  # 初始资金10万
shares_held = 0.0   # 持股数量
entry_price = 0.0   # 入场价格
entry_date = ''     # 入场日期
trades = []
daily_equity = []

n = len(records)
for i in range(20, n):  # Start after 20 days for MA calculation
    r = records[i]
    ma5 = ma(records, 5, i)
    ma10 = ma(records, 10, i)
    ma20 = ma(records, 20, i)
    ma60_val = ma(records, min(40, i+1), i)  # approximate
    
    prev = records[i-1]
    prev2 = records[i-2] if i >= 2 else prev
    
    vol_5 = avg_vol(records, 5, i)
    
    # ---- SELL CHECK (if holding) ----
    if shares_held > 0:
        pnl_pct = (r['close'] - entry_price) / entry_price * 100
        
        sell_signal = None
        
        # Stop loss: -5%
        if pnl_pct <= -5:
            sell_signal = f"止损 -5% (入场{entry_price:.2f}→现价{r['close']:.2f}, 亏损{pnl_pct:.1f}%)"
        
        # MA20 break (close below MA20 while previous day was above)
        elif ma20 and r['close'] < ma20:
            prev_ma20 = ma(records, 20, i-1)
            if prev_ma20 and prev['close'] >= prev_ma20:
                sell_signal = f"跌破MA20 ({ma20:.2f})"
        
        # Time stop: 5 consecutive days no profit (all closing prices below entry)
        hold_days = 0
        for j in range(i-1, -1, -1):
            if records[j]['date'] == entry_date:
                hold_days = i - j
                break
        if hold_days >= 5 and pnl_pct < -1:
            sell_signal = f"时间止损 (持仓{hold_days}天, 亏损{pnl_pct:.1f}%)"
        
        # Take profit: +8%
        elif pnl_pct >= 8:
            sell_signal = f"止盈 +{pnl_pct:.1f}%"
        
        # 2 consecutive down days > 1% each
        if r['pct'] < -1 and prev['pct'] < -1:
            if sell_signal is None:
                sell_signal = f"连续2日下跌超1% ({prev['pct']:.1f}%, {r['pct']:.1f}%)"
        
        if sell_signal:
            sell_cash = shares_held * r['close']
            trade_pnl_amt = (r['close'] - entry_price) * shares_held
            trades.append({
                'entry_date': entry_date,
                'entry_price': entry_price,
                'exit_date': r['date'],
                'exit_price': r['close'],
                'pnl_pct': pnl_pct,
                'pnl_amt': trade_pnl_amt,
                'reason': sell_signal,
                'shares': shares_held
            })
            capital += sell_cash
            print(f"\n{'='*50}")
            print(f"🔴 卖出: {r['date']} @ {r['close']:.2f}")
            print(f"   入场: {entry_date} @ {entry_price:.2f}")
            print(f"   股数: {shares_held:.0f} | 盈亏: {pnl_pct:+.2f}% ({trade_pnl_amt:+.0f}元)")
            print(f"   现金: {capital:.0f}元")
            print(f"   原因: {sell_signal}")
            shares_held = 0
            entry_price = 0
            entry_date = ''
    
    # ---- BUY CHECK (if no position) ----
    if shares_held == 0 and ma20 and capital > 0:
        buy_signals = []
        
        # Gate 1: MA20 trending up or flat
        ma20_prev = ma(records, 20, i-1)
        if ma20_prev:
            ma20_slope = (ma20 - ma20_prev) / ma20_prev * 100
            if ma20_slope > -0.5:  # Not in clear downtrend
                buy_signals.append(f"MA20趋势OK (斜率{ma20_slope:+.2f}%)")
        
        # Gate 2: Price near MA20 support (within +3%)
        if ma20:
            dist_to_ma20 = (r['close'] - ma20) / ma20 * 100
            if 0 <= dist_to_ma20 <= 3:
                buy_signals.append(f"接近MA20支撑 (距离{dist_to_ma20:+.1f}%)")
            elif -2 < dist_to_ma20 < 0:
                buy_signals.append(f"小幅跌破MA20 (距离{dist_to_ma20:+.1f}%)")
        
        # Gate 3: Pullback day (buy on weakness)
        if r['pct'] < 0:
            buy_signals.append(f"回调日 ({r['pct']:+.2f}%)")
        
        # Gate 4: Volume contraction
        if vol_5 and r['vol'] < vol_5 * 0.85:
            buy_signals.append(f"缩量 (量={r['vol']:.0f}万 < 5日均{vol_5:.0f}万)")
        
        # Gate 5: Price above MA60 (medium-term trend)
        if ma60_val and r['close'] > ma60_val:
            buy_signals.append(f"站上MA60 ({ma60_val:.2f})")
        
        # Need at least 3 signals
        if len(buy_signals) >= 3:
            # Buy with 50% of capital
            buy_amount = capital * 0.5
            shares_held = buy_amount / r['close']
            entry_price = r['close']
            entry_date = r['date']
            capital -= buy_amount
            
            print(f"\n{'='*50}")
            print(f"🟢 买入: {r['date']} @ {r['close']:.2f}")
            print(f"   仓位: {buy_amount:.0f}元 ({shares_held:.0f}股) | 剩余现金: {capital:.0f}元")
            print(f"   信号: {' | '.join(buy_signals)}")
    
    # Track daily equity
    if shares_held > 0:
        equity = capital + shares_held * r['close']
    else:
        equity = capital
    daily_equity.append((r['date'], equity, shares_held > 0, r['close']))

# Close any remaining position at last price
if shares_held > 0:
    last = records[-1]
    sell_cash = shares_held * last['close']
    trade_pnl_amt = (last['close'] - entry_price) * shares_held
    pnl_pct_final = (last['close'] - entry_price) / entry_price * 100
    trades.append({
        'entry_date': entry_date,
        'entry_price': entry_price,
        'exit_date': last['date'],
        'exit_price': last['close'],
        'pnl_pct': pnl_pct_final,
        'pnl_amt': trade_pnl_amt,
        'reason': '回测结束强制平仓',
        'shares': shares_held
    })
    capital += sell_cash
    shares_held = 0

# ============ RESULTS ============
print("\n" + "=" * 70)
print("📊 回测结果汇总")
print("=" * 70)

print(f"\n初始资金: 100,000 元")
print(f"最终资金: {capital:.0f} 元")
print(f"总收益率: {(capital-100000)/100000*100:+.2f}%")
print(f"总交易次数: {len(trades)} 笔")

if trades:
    wins = [t for t in trades if t['pnl_pct'] > 0]
    losses = [t for t in trades if t['pnl_pct'] <= 0]
    win_rate = len(wins) / len(trades) * 100 if trades else 0
    
    print(f"\n胜率: {win_rate:.1f}% ({len(wins)}胜{len(losses)}负)")
    
    if wins:
        avg_win = sum(t['pnl_pct'] for t in wins) / len(wins)
        print(f"平均盈利: +{avg_win:.2f}%")
    if losses:
        avg_loss = sum(t['pnl_pct'] for t in losses) / len(losses)
        print(f"平均亏损: {avg_loss:.2f}%")
    
    print(f"\n--- 每笔交易明细 ---")
    for i, t in enumerate(trades):
        emoji = "✅" if t['pnl_pct'] > 0 else "❌"
        print(f"{emoji} {t['entry_date']}→{t['exit_date']}: "
              f"入场{t['entry_price']:.2f} 出场{t['exit_price']:.2f} "
              f"盈亏{t['pnl_pct']:+.2f}% ({t['pnl_amt']:+.0f}元)")
        print(f"   原因: {t['reason']}")
    
    # Calculate max drawdown
    peak = 100000
    max_dd = 0
    for _, eq, _, _ in daily_equity:
        if eq > peak:
            peak = eq
        dd = (peak - eq) / peak * 100
        if dd > max_dd:
            max_dd = dd
    print(f"\n最大回撤: {max_dd:.2f}%")

print(f"\n回测区间: {records[0]['date']} ~ {records[-1]['date']}")
print(f"交易天数: {len(records)} 个交易日")

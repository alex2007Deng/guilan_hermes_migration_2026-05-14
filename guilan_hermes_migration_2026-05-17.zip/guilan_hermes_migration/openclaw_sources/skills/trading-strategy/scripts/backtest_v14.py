#!/usr/bin/env python3
"""
归澜 v1.4 均值回归波段策略回测
区间：2023-11 ~ 2026-05（约2.5年）
策略：S.C.R.E.E.N.选股 + 三道闸门 + 相对强度过滤 + 仓位风控
"""

import json
from typing import Dict, List, Optional, Tuple

# ===================== 加载数据 =====================
with open('/tmp/backtest_v14_data.json') as f:
    stock_data = json.load(f)
with open('/tmp/backtest_v14_sectors.json') as f:
    sector_data = json.load(f)

def parse_records(datalist):
    """Parse raw API records"""
    recs = []
    for r in datalist:
        recs.append({
            'date': r['date'],
            'close': float(r.get('close', 0)),
            'open': float(r.get('open', 0)),
            'high': float(r.get('max', 0)),
            'low': float(r.get('min', 0)),
            'pct': float(r.get('priceChangePct', 0)),
            'vol': float(str(r.get('vol', '0')).replace('亿','e4').replace('万','').replace('e4','0000')) if 'vol' in r else 0,
            'ampl': float(r.get('amplitude', 0)),
        })
    recs.sort(key=lambda x: x['date'])
    return recs

# Load stock data
stocks = {}
for key, datalist in stock_data.items():
    code_name = key.split('_', 1)
    code = code_name[0]
    name = code_name[1]
    stocks[code] = {'name': name, 'records': parse_records(datalist)}

# Load sector data
sectors = {}
for key, datalist in sector_data.items():
    sname = key.split('_', 1)[1]
    sectors[sname] = parse_records(datalist)

# Map stocks to sectors
stock_sector_map = {
    '600584': '先进封装',  # 封测
    '002156': '先进封装',  # 封测
    '603986': '芯片',      # 设计
}

print("=" * 80)
print("📊 v1.4 均值回归波段策略回测")
print("回测区间: 2023-11 ~ 2026-05 (约2.5年)")
print("=" * 80)

# ===================== Helper Functions =====================
def ma(data, n, idx):
    if idx < n-1:
        return None
    return sum(data[j]['close'] for j in range(idx-n+1, idx+1)) / n

def avg_ampl(data, n, idx):
    if idx < n-1:
        return None
    return sum(data[j]['ampl'] for j in range(idx-n+1, idx+1)) / n

def avg_vol(data, n, idx):
    if idx < n-1:
        return None
    return sum(data[j]['vol'] for j in range(idx-n+1, idx+1)) / n

def date_index(data, date):
    for i, r in enumerate(data):
        if r['date'] == date:
            return i
    return -1

def count_days_beat(data_s, data_b, n, idx):
    """Count how many of last n days stock beat benchmark (pct >= benchmark pct)"""
    c = 0
    for j in range(max(0, idx-n+1), idx+1):
        b_idx = date_index(data_b, data_s[j]['date'])
        if b_idx >= 0 and data_s[j]['pct'] >= data_b[b_idx]['pct']:
            c += 1
    return c

def rel_strength_batch(data_s, data_b, n, idx):
    """Return (days_beat, total_traded_days) for last n days"""
    count = 0
    total = 0
    for j in range(max(0, idx-n+1), idx+1):
        b_idx = date_index(data_b, data_s[j]['date'])
        if b_idx >= 0:
            total += 1
            if data_s[j]['pct'] >= data_b[b_idx]['pct']:
                count += 1
    return count, total

# ===================== Backtest Engine =====================
def backtest_v14(stock_code: str, sector_name: str, capital: float = 100000) -> dict:
    """Run v1.4 strategy on one stock"""
    
    data = stocks[stock_code]['records']
    name = stocks[stock_code]['name']
    sector = sectors[sector_name]
    
    n = len(data)
    shares = 0.0
    entry_price = 0.0
    entry_date = ''
    entry_idx = -1
    cash = capital
    trades = []
    equities = []
    screened_out_days = []  # Track days stock failed S.C.R.E.E.N.
    
    # Start after 20 days (need MA20)
    for i in range(20, n):
        r = data[i]
        ma20_v = ma(data, 20, i)
        ma60_v = ma(data, 60, i)  # Only true MA60 when enough data; None otherwise
        avg_ampl_20 = avg_ampl(data, 20, i)
        avg_vol_5 = avg_vol(data, 5, i)
        
        # ============ SCREEN CHECK (for entry) ============
        screen_pass = True
        screen_reasons = []
        
        # E-Elasticity: 20-day avg amplitude >= 3.5%
        if avg_ampl_20 and avg_ampl_20 < 3.5:
            screen_pass = False
            screen_reasons.append(f"振幅{avg_ampl_20:.1f}%<3.5%")
        
        # R-Range: MA20 exists
        if ma20_v is None:
            screen_pass = False
            screen_reasons.append("MA20未形成")
        
        # S-Sector (v1.4): relative strength check
        if sector:
            beat10, total10 = rel_strength_batch(data, sector, 10, i)
            beat5, total5 = rel_strength_batch(data, sector, 5, i)
            
            if total10 >= 10 and beat10 < 5:
                # Not a hard fail but note it
                pass
            
            # Record whether stock beat sector today
            s_idx = date_index(sector, r['date'])
            today_beat = (s_idx >= 0 and r['pct'] >= sector[s_idx]['pct'])
        else:
            today_beat = True
        
        # ============ SELL CHECK (if holding) ============
        if shares > 0:
            pnl_pct = (r['close'] - entry_price) / entry_price * 100
            sell_reason = None
            sell_shares = 0
            
            # Stop loss -5%
            if pnl_pct <= -5:
                sell_reason = f"止损-5%({pnl_pct:.1f}%)"
                sell_shares = shares
            
            # MA20 break
            elif (ma20_v and r['close'] < ma20_v and 
                  date_index(data, entry_date) < i-1):  # Not on entry day
                prev_ma20 = ma(data, 20, i-1)
                if prev_ma20 and data[i-1]['close'] >= prev_ma20:
                    sell_reason = f"跌破MA20({ma20_v:.2f})"
                    sell_shares = shares / 2
            
            # MA60 break
            elif ma60_v and r['close'] < ma60_v:
                sell_reason = f"跌破MA60({ma60_v:.2f})"
                sell_shares = shares
            
            # Time stop: 5 days, still no profit
            elif i - entry_idx >= 5 and pnl_pct < -1:
                sell_reason = f"时间止损({i-entry_idx}天,{pnl_pct:.1f}%)"
                sell_shares = shares / 2
            
            # Take profit +8% (sell half)
            elif pnl_pct >= 8 and shares > entry_shares * 0.4:
                sell_reason = f"止盈+{pnl_pct:.1f}%(卖一半)"
                sell_shares = shares / 2
            
            # Take profit +15% (sell all)
            elif pnl_pct >= 15:
                sell_reason = f"止盈+{pnl_pct:.1f}%(全清)"
                sell_shares = shares
            
            # v1.3/1.4: Sector underperformance exit
            elif sector and today_beat is False:
                # Check if 2 consecutive days underperforming sector
                prev_s_idx = date_index(sector, data[i-1]['date'])
                prev_beat = (prev_s_idx >= 0 and data[i-1]['pct'] >= sector[prev_s_idx]['pct'])
                
                s_today = date_index(sector, r['date'])
                if s_today >= 0:
                    sector_pct = sector[s_today]['pct']
                    # 板块大涨>2% but 个股<1%
                    if sector_pct > 2 and r['pct'] < 1:
                        sell_reason = f"板块大涨不跟(板块{sector_pct:.1f}%vs个股{r['pct']:.1f}%)"
                        sell_shares = shares / 2
                    # 连续2日跑输
                    elif not prev_beat and not today_beat:
                        sell_reason = f"连续2日跑输板块"
                        sell_shares = shares / 2
            
            if sell_reason and sell_shares > 0:
                sell_cash = sell_shares * r['close']
                trade_pnl_amt = (r['close'] - entry_price) * sell_shares
                trades.append({
                    'entry_date': entry_date,
                    'exit_date': r['date'],
                    'entry_price': entry_price,
                    'exit_price': r['close'],
                    'pnl_pct': pnl_pct,
                    'pnl_amt': trade_pnl_amt,
                    'shares': sell_shares,
                    'reason': sell_reason
                })
                cash += sell_cash
                shares -= sell_shares
                
                if shares <= 0.01:
                    shares = 0
                    entry_price = 0
                    entry_date = ''
                    entry_idx = -1
                else:
                    # Partial sell - adjust entry tracking
                    entry_shares = shares
        
        # ============ BUY CHECK (if no position) ============
        if shares == 0 and cash > 0 and screen_pass:
            signals = []
            
            # Gate 2: Sector rising
            if sector:
                s_idx = date_index(sector, r['date'])
                if s_idx >= 0:
                    if sector[s_idx]['pct'] > -0.5:  # Sector not declining
                        signals.append(f"板块OK({sector[s_idx]['pct']:+.2f}%)")
                    
                    # v1.4: Today's relative strength
                    if today_beat:
                        signals.append("今日跑赢板块")
            
            # Gate 3a: Volume contraction
            if avg_vol_5 and r['vol'] < avg_vol_5 * 0.85:
                signals.append("缩量")
            
            # Gate 3b: Pullback day
            if r['pct'] < 0 and r['close'] > r['open'] * 0.97:
                signals.append("回调但尾盘拉回")
            
            # Gate 3c: Near MA20 support
            if ma20_v and 0 < (r['close'] - ma20_v) / ma20_v * 100 <= 3:
                signals.append(f"近MA20支撑")
            
            # Gate 3d: MA20 trend
            if ma20_v:
                prev_ma20 = ma(data, 20, i-1)
                if prev_ma20 and ma20_v >= prev_ma20:
                    signals.append("MA20向上")
            
            # Gate 3e: Above MA60
            if ma60_v and r['close'] > ma60_v:
                signals.append("站上MA60")
            
            # Need ≥3 signals
            if len(signals) >= 3:
                buy_amount = cash * 0.5
                shares = buy_amount / r['close']
                entry_price = r['close']
                entry_date = r['date']
                entry_idx = i
                entry_shares = shares
                cash -= buy_amount
                
                trades.append({
                    'entry_date': entry_date,
                    'exit_date': '',
                    'entry_price': entry_price,
                    'exit_price': 0,
                    'pnl_pct': 0,
                    'pnl_amt': 0,
                    'shares': entry_shares,
                    'reason': f"BUY|{'|'.join(signals)}"
                })
        
        # Track equity
        if shares > 0:
            eq = cash + shares * r['close']
        else:
            eq = cash
        equities.append((r['date'], eq))
    
    # Close remaining position
    if shares > 0:
        last = data[-1]
        pnl_final = (last['close'] - entry_price) / entry_price * 100
        trades.append({
            'entry_date': entry_date,
            'exit_date': last['date'],
            'entry_price': entry_price,
            'exit_price': last['close'],
            'pnl_pct': pnl_final,
            'pnl_amt': (last['close'] - entry_price) * shares,
            'shares': shares,
            'reason': '回测结束平仓'
        })
        cash += shares * last['close']
        shares = 0
    
    # Calculate metrics
    final_eq = equities[-1][1] if equities else cash
    total_return = (final_eq - capital) / capital * 100
    
    # Filter out BUY entries for trade statistics (only exits)
    exit_trades = [t for t in trades if t['exit_date']]
    if exit_trades:
        wins = [t for t in exit_trades if t['pnl_pct'] > 0]
        losses = [t for t in exit_trades if t['pnl_pct'] <= 0]
        win_rate = len(wins) / len(exit_trades) * 100
        avg_win = sum(t['pnl_pct'] for t in wins) / len(wins) if wins else 0
        avg_loss = sum(t['pnl_pct'] for t in losses) / len(losses) if losses else 0
        total_pnl_pct = sum(t['pnl_pct'] for t in exit_trades)
    else:
        win_rate = avg_win = avg_loss = total_pnl_pct = 0
    
    # Max drawdown
    peak = capital
    max_dd = 0
    for _, eq in equities:
        if eq > peak:
            peak = eq
        dd = (peak - eq) / peak * 100
        if dd > max_dd:
            max_dd = dd
    
    # Buy & hold comparison
    bh_return = (data[-1]['close'] - data[20]['close']) / data[20]['close'] * 100
    
    return {
        'code': stock_code,
        'name': name,
        'sector': sector_name,
        'initial_capital': capital,
        'final_equity': final_eq,
        'total_return': total_return,
        'buy_hold_return': bh_return,
        'trades': len(exit_trades),
        'win_rate': win_rate,
        'avg_win': avg_win,
        'avg_loss': avg_loss,
        'total_pnl_pct': total_pnl_pct,
        'max_drawdown': max_dd,
        'trade_details': [t for t in trades if t['exit_date']]
    }

# ===================== Run Backtests =====================
results = []
for code in ['600584', '603986', '002156']:
    sector = stock_sector_map.get(code, '半导体')
    print(f"\n{'─'*60}")
    print(f"🔬 回测 {stocks[code]['name']} ({code}) vs {sector}板块...")
    r = backtest_v14(code, sector)
    results.append(r)
    print(f"   收益率: {r['total_return']:+.2f}% | B&H: {r['buy_hold_return']:+.2f}%")
    print(f"   胜率: {r['win_rate']:.0f}% | 交易: {r['trades']}笔 | 最大回撤: {r['max_drawdown']:.2f}%")

# ===================== Summary =====================
print("\n" + "=" * 80)
print("📊 v1.4 策略回测汇总 (2023-11 ~ 2026-05, 约2.5年)")
print("=" * 80)

print(f"\n{'股票':<16} {'策略收益':>10} {'买入持有':>10} {'胜率':>8} {'交易':>6} {'最大回撤':>10} {'均盈':>8} {'均亏':>8}")
print("-" * 85)
for r in results:
    print(f"{r['name']:<10}({r['code']}) {r['total_return']:>+8.2f}% {r['buy_hold_return']:>+10.2f}% "
          f"{r['win_rate']:>6.1f}% {r['trades']:>4}笔 {r['max_drawdown']:>8.2f}% "
          f"{r['avg_win']:>+7.2f}% {r['avg_loss']:>+7.2f}%")

# Portfolio average (equal weight)
avg_return = sum(r['total_return'] for r in results) / len(results)
avg_bh = sum(r['buy_hold_return'] for r in results) / len(results)
avg_dd = sum(r['max_drawdown'] for r in results) / len(results)
avg_wr = sum(r['win_rate'] for r in results) / len(results)

print(f"\n{'组合平均':<16} {avg_return:>+8.2f}% {avg_bh:>+10.2f}% "
      f"{avg_wr:>6.1f}% {'─':>6} {avg_dd:>8.2f}%")

print(f"\n🎯 策略超额: {avg_return - avg_bh:+.2f}% vs 买入持有")
print(f"🛡️ 风险控制: 策略最大回撤 {avg_dd:.2f}% vs 买入持有波动")

# Print detailed trades for best performer
best = max(results, key=lambda r: r['total_return'])
print(f"\n{'─'*60}")
print(f"🏆 最佳: {best['name']}({best['code']}) 交易明细")
print(f"{'─'*60}")
for i, t in enumerate(best['trade_details']):
    emoji = "✅" if t['pnl_pct'] > 0 else "❌"
    print(f"  {emoji} [{i+1}] {t['entry_date']}→{t['exit_date']}: "
          f"入场{t['entry_price']:.2f} 出场{t['exit_price']:.2f} "
          f"盈亏{t['pnl_pct']:+.2f}% ({t['pnl_amt']:+.0f}元)")
    print(f"      原因: {t['reason']}")

print("\n" + "=" * 80)
print("⚠️ 风险提示: 历史回测不代表未来表现，仅供参考")
print("=" * 80)

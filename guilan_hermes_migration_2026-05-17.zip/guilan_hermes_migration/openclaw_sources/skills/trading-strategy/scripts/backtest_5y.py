#!/usr/bin/env python3
"""
归澜 v1.4.1 全系统 5 年回测 (2021-03 ~ 2026-05)
21股候选池 × S.C.R.E.E.N. × S-Sector 2.0 × F-Flow × 三道闸门 × 轮动
"""

import json
from collections import defaultdict

with open('/tmp/guilun_5y_stocks.json') as f: stock_data = json.load(f)
with open('/tmp/guilun_5y_sectors.json') as f: sector_data = json.load(f)

# Parse
stocks = {}
for k, v in stock_data.items():
    code = k.split('_')[0]; name = k.split('_',1)[1]
    for r in v:
        if 'pct' not in r and r.get('open',0) > 0:
            r['pct'] = round((r['close']/r['open']-1)*100, 2)
    stocks[code] = {'name': name, 'records': v}

sectors = {}
for k, v in sector_data.items(): sectors[k] = v

# S-Sector 2.0 grade mapping
SECTOR_GRADE = {
    '603986': ('数字芯片设计','gold'), '002371': ('半导体设备','gold'),
    '002049': ('数字芯片设计','gold'), '603501': ('数字芯片设计','gold'),
    '300661': ('数字芯片设计','gold'), '688012': ('半导体设备','gold'),
    '300782': ('数字芯片设计','gold'), '688981': ('半导体','gold'),
    '300750': ('锂电池','silver'), '002594': ('新能源','silver'),
    '002415': ('半导体','gold'), '300124': ('机器人','silver'),
    '002230': ('半导体','gold'), '002460': ('锂电池','silver'),
    '600519': ('半导体','bronze'), '300760': ('半导体','bronze'),
    '601318': ('半导体','bronze'), '000858': ('半导体','bronze'),
    # Blacklist
    '600584': ('集成电路封测','blacklist'), '002156': ('集成电路封测','blacklist'),
    '601012': ('光伏设备','blacklist'),
}
BLACKLIST = {c for c,(_,g) in SECTOR_GRADE.items() if g=='blacklist'}
GRADE_BONUS = {'gold':20,'silver':12,'bronze':5,'blacklist':-999}

def ma(d, n, i):
    if i < n-1: return None
    return sum(d[j]['close'] for j in range(i-n+1,i+1))/n

def avg_ampl(d, n, i):
    if i < n-1: return None
    return sum(d[j]['amplitude'] for j in range(i-n+1,i+1))/n

def di(d, date):
    for i, r in enumerate(d):
        if r['date']==date: return i
    return -1

def count_beat(ds, db, n, i):
    c = 0
    for j in range(max(0,i-n+1), i+1):
        b = di(db, ds[j]['date'])
        if b >= 0 and ds[j]['pct'] >= db[b]['pct']: c += 1
    return c

def fflow_score(data, i):
    """Approximate fund flow from K-line: volume-price divergence"""
    r = data[i]
    score = 0
    if i >= 5:
        # Rising price on declining volume = accumulation (positive)
        vol_trend = sum(1 for j in range(i-4,i) if data[j+1]['vol']<data[j]['vol'])
        price_trend = sum(1 for j in range(i-4,i) if data[j+1]['close']>data[j]['close'])
        if price_trend >= 3 and vol_trend >= 3:
            score = 8  # Strong accumulation
        elif price_trend >= 3:
            score = 5
        elif price_trend <= 1 and vol_trend <= 1:
            score = -5  # Distribution
    return score

# Build date index for all stocks
print("Building date index...")
date_idx = {}
for code in stocks:
    date_idx[code] = {r['date']:i for i,r in enumerate(stocks[code]['records'])}

# Find common trading period
all_dates = set()
for code in stocks:
    for r in stocks[code]['records']:
        all_dates.add(r['date'])
trading_dates = sorted(all_dates)

# Start when most stocks have 60+ days
start = None
for date in trading_dates:
    cnt = sum(1 for c in stocks if date_idx[c].get(date,-1) >= 60)
    if cnt >= 10:
        start = date; break

dates = [d for d in trading_dates if d >= start]
print(f"回测: {start} ~ {dates[-1]}, {len(dates)}天, {len(stocks)}只候选")

# ==================== Engine ====================
capital = 100000; cash = 100000
positions = {}  # code->{shares,entry,entry_date,entry_i}
trades = []; equities = []; pool = []
MAX_POS = 3; REBALANCE = 10  # ~biweekly

for di_t in range(len(dates)):
    date = dates[di_t]
    rebalance = (di_t % REBALANCE == 0)
    
    # Current indices
    idx = {c: date_idx[c].get(date,-1) for c in stocks}
    
    # ---- EXITS ----
    for code in list(positions.keys()):
        i = idx[code]; 
        if i < 60: continue
        pos = positions[code]; data = stocks[code]['records']; r = data[i]
        pnl = (r['close']-pos['entry'])/pos['entry']*100
        sell = None
        
        if pnl <= -5: sell = ('止损', 1.0)
        elif ma(data,60,i) and r['close']<ma(data,60,i): sell = ('破MA60', 1.0)
        elif pnl >= 8 and pos['shares']>pos['init_shares']*0.4: sell = ('止盈半仓', 0.5)
        elif pnl >= 15: sell = ('止盈全清', 1.0)
        elif ma(data,20,i) and r['close']<ma(data,20,i) and data[i-1]['close']>=ma(data,20,i-1):
            sell = ('破MA20', 0.5)
        elif i-pos['entry_i']>=7 and pnl<-1: sell = ('时间止损', 0.5)
        
        if sell:
            qty = pos['shares']*sell[1]
            pnl_amt = (r['close']-pos['entry'])*qty
            trades.append({'code':code,'name':stocks[code]['name'],
                'entry':pos['entry_date'],'exit':date,'entry_p':pos['entry'],'exit_p':r['close'],
                'pnl_pct':pnl,'pnl_amt':pnl_amt,'reason':sell[0]})
            cash += qty*r['close']; pos['shares'] -= qty
            if pos['shares']<1: del positions[code]
    
    # ---- WEEKLY REBALANCE ----
    if rebalance:
        candidates = []
        for code in stocks:
            i = idx[code]
            if i < 60: continue
            if code in BLACKLIST: continue
            data = stocks[code]['records']; r = data[i]
            ampl = avg_ampl(data,20,i)
            if ampl is None or ampl < 3.0: continue  # Relaxed for 5-year period
            sector_name, grade = SECTOR_GRADE.get(code,('半导体','bronze'))
            score = min(ampl,15)*3 + GRADE_BONUS.get(grade,5)
            # Relative strength
            sec = sectors.get(sector_name)
            if sec: score += count_beat(data, sec, 5, i)*2
            # F-Flow proxy
            score += fflow_score(data, i)
            # Momentum
            if i>=5: score += (r['close']/data[i-5]['close']-1)*50
            candidates.append((code,score,grade))
        
        candidates.sort(key=lambda x:x[1], reverse=True)
        pool = candidates[:10]
        
        # Exit positions dropped from top 5
        top_codes = {c for c,_,_ in candidates[:5]}
        for code in list(positions.keys()):
            if code not in top_codes and code not in BLACKLIST:
                i = idx[code]; 
                if i>=0:
                    r = stocks[code]['records'][i]; pos = positions[code]
                    pnl = (r['close']-pos['entry'])/pos['entry']*100
                    trades.append({'code':code,'name':stocks[code]['name'],
                        'entry':pos['entry_date'],'exit':date,'entry_p':pos['entry'],'exit_p':r['close'],
                        'pnl_pct':pnl,'pnl_amt':(r['close']-pos['entry'])*pos['shares'],
                        'reason':'跌出精选池'})
                    cash += pos['shares']*r['close']
                    del positions[code]
    
    # ---- ENTRIES ----
    if cash > 5000 and len(positions) < MAX_POS:
        for code, score, grade in pool:
            if code in positions or len(positions) >= MAX_POS: continue
            i = idx[code]; 
            if i < 60: continue
            data = stocks[code]['records']; r = data[i]
            signals = 0
            # Gate signals (simplified for backtest)
            m20 = ma(data,20,i); m60 = ma(data,60,i)
            if m20 and m60 and m20 >= m60: signals += 1
            if m20 and r['close'] > m20: signals += 1
            if r['close'] > r['low']*1.01: signals += 1
            if grade in ('gold','silver'): signals += 1
            
            if signals >= 3:
                buy_amt = cash*0.35
                shares = buy_amt/r['close']
                positions[code] = {'shares':shares,'entry':r['close'],
                    'entry_date':date,'entry_i':i,'init_shares':shares}
                cash -= buy_amt
                trades.append({'code':code,'name':stocks[code]['name'],
                    'entry':date,'exit':'','entry_p':r['close'],'exit_p':0,
                    'pnl_pct':0,'pnl_amt':0,'reason':f'BUY|{grade}|评分{score:.0f}'})
    
    # Track equity
    eq = cash
    for c, p in positions.items():
        i = idx[c]; 
        if i >= 0: eq += p['shares']*stocks[c]['records'][i]['close']
    equities.append((date, eq))

# Close all
for code, pos in list(positions.items()):
    r = stocks[code]['records'][-1]
    pnl = (r['close']-pos['entry'])/pos['entry']*100
    trades.append({'code':code,'name':stocks[code]['name'],
        'entry':pos['entry_date'],'exit':r['date'],'entry_p':pos['entry'],'exit_p':r['close'],
        'pnl_pct':pnl,'pnl_amt':(r['close']-pos['entry'])*pos['shares'],'reason':'期末平仓'})
    cash += pos['shares']*r['close']
positions.clear()

# ==================== Results ====================
final_eq = equities[-1][1]
total_ret = (final_eq-100000)/100000*100

# B&H equal weight (exclude blacklist)
bh_ret = 0; bh_n = 0
for code in stocks:
    if code in BLACKLIST: continue
    data = stocks[code]['records']
    start_i = next((i for i,r in enumerate(data) if r['date']>=start), 60)
    if start_i < len(data):
        bh_ret += (data[-1]['close']/data[start_i]['close']-1)*100
        bh_n += 1
bh_ret /= bh_n if bh_n else 1

exits = [t for t in trades if t.get('exit')]
wins = [t for t in exits if t['pnl_pct']>0]
losses = [t for t in exits if t['pnl_pct']<=0]
wr = len(wins)/len(exits)*100 if exits else 0
aw = sum(t['pnl_pct'] for t in wins)/len(wins) if wins else 0
al = sum(t['pnl_pct'] for t in losses)/len(losses) if losses else 0

peak = 100000; max_dd = 0
for _,eq in equities:
    if eq>peak: peak=eq
    dd = (peak-eq)/peak*100
    if dd>max_dd: max_dd=dd

# By grade
by_grade = defaultdict(lambda: {'w':0,'l':0,'pnl':0})
for t in exits:
    g = SECTOR_GRADE.get(t['code'],('?','bronze'))[1]
    by_grade[g]['w' if t['pnl_pct']>0 else 'l'] += 1
    by_grade[g]['pnl'] += t['pnl_amt']
by_stock = defaultdict(lambda: {'w':0,'l':0,'pnl':0})
for t in exits:
    by_stock[t['name']]['w' if t['pnl_pct']>0 else 'l'] += 1
    by_stock[t['name']]['pnl'] += t['pnl_amt']

# ==================== Print ====================
print(f"\n{'='*70}")
print(f"📊 归澜 v1.4.1 全系统 5 年回测")
print(f"区间: {start} ~ {dates[-1]} | {len(dates)} 交易日 | {len(stocks)}只候选")
print(f"{'='*70}")
print(f"策略收益: {total_ret:+.2f}%")
print(f"买入持有: {bh_ret:+.2f}% (等权,排除黑名单)")
print(f"最大回撤: {max_dd:.2f}%")
print(f"胜率: {wr:.0f}% ({len(wins)}胜{len(losses)}负)")
print(f"均盈: +{aw:.2f}% | 均亏: {al:.2f}%")
if aw>0 and abs(al)>0: print(f"盈亏比: {aw/abs(al):.2f}")

print(f"\n--- 赛道统计 ---")
for g in ['gold','silver','bronze']:
    d = by_grade[g]
    total = d['w']+d['l']
    if total:
        print(f"  {'🥇' if g=='gold' else '🥈' if g=='silver' else '🥉'} {g}: {d['w']}胜{d['l']}负 "
              f"净盈亏{d['pnl']:+.0f}元")

print(f"\n--- 各股票贡献 Top 10 ---")
ranked = sorted(by_stock.items(), key=lambda x:x[1]['pnl'], reverse=True)[:10]
for name, d in ranked:
    total = d['w']+d['l']
    print(f"  {name:<8} {d['w']:>3}胜{d['l']:>3}负 净{d['pnl']:>+8.0f}元")

print(f"\n--- 年化收益 ---")
years = len(dates)/242
cagr = ((final_eq/100000)**(1/years)-1)*100 if years>0 else 0
print(f"  年化: {cagr:+.2f}% | 夏普近似: {(cagr-2.5)/max_dd:.2f}" if max_dd>0 else "")

print(f"\n⚠️ 历史回测不代表未来表现")

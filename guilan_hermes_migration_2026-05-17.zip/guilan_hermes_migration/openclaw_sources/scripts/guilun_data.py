#!/usr/bin/env python3
"""
归澜数据适配层 — 东方财富数据源 v2.0
替代国信 API 的无限量行情数据接口
S-Sector 2.0 基于概念板块实际归属分类

核心能力:
  1. 全A股列表 + 实时行情（无数量限制）
  2. 历史日K线（无限天数）
  3. 板块/概念成分股（含实时涨跌幅，用于板块内排名）
  4. 板块指数K线
  5. S.C.R.E.E.N. + S-Sector 2.0 筛选（概念归属分类）

用法:
  from guilun_data import GuilunData, GuilunScreen
  gd = GuilunData()
  screen = GuilunScreen(gd)
  candidates = screen.screen()  # 全A股S.C.R.E.E.N.筛选
"""

import urllib.request
import json
import time
import ssl
from typing import Dict, List, Optional, Tuple
from collections import defaultdict

ssl._create_default_https_context = ssl._create_unverified_context

# ============================================================
# S-Sector 2.0 概念板块→赛道等级映射（基于东方财富概念板块代码）
# ============================================================
CONCEPT_GRADE_MAP = {
    # 🥇 黄金赛道：政策+需求+资金三方共振
    'BK1036': 'gold',   # 半导体
    'BK1326': 'gold',   # 半导体设备
    'BK1331': 'gold',   # 数字芯片设计
    'BK1330': 'gold',   # 模拟芯片设计
    'BK0894': 'gold',   # 国产芯片
    'BK1139': 'gold',   # 存储芯片
    'BK1160': 'gold',   # CPO概念
    'BK0858': 'gold',   # 华为海思
    'BK1325': 'gold',   # 半导体材料
    'BK0952': 'gold',   # 第三代半导体
    'BK1161': 'gold',   # 先进封装（设计+设备侧，非封测代工）
    
    # 🥈 白银赛道：两因素共振
    'BK1122': 'silver',  # 汽车芯片
    'BK1408': 'silver',  # 机器人
    'BK1091': 'silver',  # 机器人概念
    'BK0680': 'silver',  # 无人驾驶
    'BK1529': 'silver',  # 汽车电子电气系统
    'BK1233': 'silver',  # 军工电子Ⅱ
    'BK1386': 'silver',  # 军工电子Ⅲ
    'BK0645': 'silver',  # 智能穿戴
    'BK0493': 'silver',  # 新能源
    'BK0444': 'silver',  # 锂电池
    'BK1032': 'silver',  # 风电设备
    'BK1041': 'silver',  # 医疗器械
    'BK1288': 'silver',  # 金属新材料
    'BK0477': 'silver',  # 新材料
    'BK0675': 'silver',  # 汽车电子
    
    # ⛔ 黑名单：产能过剩/政策打压/低毛利
    'BK1328': 'blacklist',  # 集成电路封测
    'BK1315': 'blacklist',  # 光伏电池组件
    'BK1319': 'blacklist',  # 硅料硅片
    'BK1031': 'blacklist',  # 光伏设备
    'BK1316': 'blacklist',  # 光伏辅材
    'BK1317': 'blacklist',  # 光伏加工设备
    'BK1318': 'blacklist',  # 光伏主材
    'BK1375': 'blacklist',  # 光伏发电
    'BK0740': 'blacklist',  # 教育
    'BK1202': 'blacklist',  # 房地产
    'BK0451': 'blacklist',  # 房地产开发
    'BK1045': 'blacklist',  # 房地产服务
    'BK1224': 'blacklist',  # 纺织制造
    'BK0436': 'blacklist',  # 纺织服饰
    'BK0424': 'blacklist',  # 水泥
    'BK0437': 'blacklist',  # 煤炭
    'BK0479': 'blacklist',  # 钢铁
    'BK0450': 'blacklist',  # 航运港口
    'BK0567': 'blacklist',  # 高速公路
}
# Everything else → bronze (default)

# Grade scoring bonus
GRADE_SCORE = {'gold': 20, 'silver': 12, 'bronze': 5, 'blacklist': -999}


class GuilunData:
    """归澜数据引擎 — 东方财富数据源"""
    
    BASE_QUOTE = 'http://push2.eastmoney.com/api/qt/clist/get'
    BASE_KLINE = 'http://push2his.eastmoney.com/api/qt/stock/kline/get'
    
    def __init__(self, cache_ttl=300):
        self._cache = {}
        self._cache_time = {}
        self._ttl = cache_ttl
        # Lazy-loaded concept reverse index: stock_code → set of concept BK codes
        self._concept_index = None
    
    def _get_json(self, url: str, timeout: int = 15) -> dict:
        now = time.time()
        if url in self._cache and (now - self._cache_time.get(url, 0)) < self._ttl:
            return self._cache[url]
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
            'Referer': 'http://quote.eastmoney.com/'
        })
        try:
            resp = json.loads(urllib.request.urlopen(req, timeout=timeout).read())
            self._cache[url] = resp
            self._cache_time[url] = now
            return resp
        except Exception as e:
            return {}
    
    # ==================== 1. 全A股列表 ====================
    def get_all_stocks(self, market='all', sort_by='f3', desc=True) -> List[dict]:
        market_fs = {
            'all': 'm:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23',
            'sh': 'm:1+t:2,m:1+t:23',
            'sz': 'm:0+t:6,m:0+t:80',
            'bj': 'm:0+t:81',
            'kcb': 'm:1+t:23',
            'cyb': 'm:0+t:80',
        }
        fs = market_fs.get(market, market_fs['all'])
        fields = 'f2,f3,f4,f5,f6,f7,f8,f9,f12,f14,f15,f16,f17,f18,f20'
        all_stocks = []
        page = 1
        while True:
            url = (f'{self.BASE_QUOTE}?pn={page}&pz=100&po={1 if desc else 0}'
                   f'&np=1&fltt=2&invt=2&fid={sort_by}&fs={fs}&fields={fields}')
            resp = self._get_json(url)
            items = (resp.get('data') or {}).get('diff', [])
            if not items: break
            for item in items:
                if item.get('f12') and item.get('f2', '-') != '-':
                    all_stocks.append({
                        'code': item['f12'],
                        'name': item.get('f14', ''),
                        'price': item.get('f2', 0), 'pct': item.get('f3', 0),
                        'change': item.get('f4', 0), 'vol': item.get('f5', 0),
                        'amount': item.get('f6', 0), 'amplitude': item.get('f7', 0),
                        'turnover': item.get('f8', 0), 'pe': item.get('f9', 0),
                        'high': item.get('f15', 0), 'low': item.get('f16', 0),
                        'open': item.get('f17', 0), 'prev_close': item.get('f18', 0),
                        'market_cap': item.get('f20', 0),
                    })
            if len(items) < 100: break
            page += 1
            time.sleep(0.05)
        return all_stocks
    
    # ==================== 2. 历史K线 ====================
    def get_kline(self, code: str, days: int = 600, fqt: int = 1) -> List[dict]:
        market = '0' if code.startswith(('0','3')) else '1'
        secid = f'{market}.{code}'
        url = (f'{self.BASE_KLINE}?secid={secid}&fields1=f1,f2,f3,f4,f5,f6'
               f'&fields2=f51,f52,f53,f54,f55,f56,f57,f58'
               f'&klt=101&fqt={fqt}&end=20500101&lmt={days}')
        resp = self._get_json(url)
        records = []
        for k in (resp.get('data') or {}).get('klines', []):
            parts = k.split(',')
            if len(parts) >= 7:
                o, c, h, l = float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])
                records.append({
                    'date': parts[0], 'open': o, 'close': c, 'high': h, 'low': l,
                    'vol': float(parts[5]), 'amount': float(parts[6]),
                    'amplitude': float(parts[7]) if len(parts) > 7 and parts[7] != '-' 
                                 else ((h-l)/c*100 if c>0 else 0),
                    'pct': round((c / o - 1) * 100, 2)
                })
        return records
    
    # ==================== 3. 概念板块指数构建 ====================
    def _build_concept_index(self):
        """构建股票→概念板块反向索引（首次调用时构建，缓存）"""
        if self._concept_index is not None:
            return
        
        self._concept_index = defaultdict(set)
        total_boards = len(CONCEPT_GRADE_MAP)
        loaded = 0
        
        for bk_code, grade in CONCEPT_GRADE_MAP.items():
            page = 1
            while True:
                url = (f'{self.BASE_QUOTE}?pn={page}&pz=500&po=1&np=1'
                       f'&fltt=2&invt=2&fid=f3&fs=b:{bk_code}&fields=f12')
                resp = self._get_json(url) or {}
                data_block = resp.get('data')
                items = (data_block or {}).get('diff', [])
                if not items: break
                for item in items:
                    self._concept_index[item['f12']].add(bk_code)
                if len(items) < 500: break
                page += 1
                time.sleep(0.05)
            loaded += 1
            if loaded % 10 == 0:
                print(f"  [概念索引] {loaded}/{total_boards} 板块已加载")
    
    def classify_stock(self, code: str) -> Tuple[str, List[str]]:
        """
        S-Sector 2.0 股票赛道分类
        返回: (grade, [匹配的概念板块列表])
        """
        self._build_concept_index()
        concepts = self._concept_index.get(code, set())
        if not concepts:
            return 'bronze', []
        
        grades_found = []
        for bk in concepts:
            grade = CONCEPT_GRADE_MAP.get(bk)
            if grade:
                grades_found.append((grade, bk))
        
        if not grades_found:
            return 'bronze', []
        
        # Priority: blacklist > gold > silver > bronze
        for grade in ['blacklist', 'gold', 'silver']:
            matching = [bk for g, bk in grades_found if g == grade]
            if matching:
                return grade, matching
        
        return 'bronze', []
    
    def get_stock_concepts(self, code: str) -> List[str]:
        """获取股票的所有已知概念板块代码"""
        self._build_concept_index()
        return list(self._concept_index.get(code, set()))
    
    # ==================== 4. 板块成分股 ====================
    def get_sector_stocks(self, sector: str) -> List[dict]:
        """获取概念/行业板块全部成分股"""
        # Look up BK code
        bk_code = sector if sector.startswith('BK') else None
        if not bk_code:
            for sname, code in CONCEPT_GRADE_MAP.items():
                if sector in sname:
                    bk_code = sname
                    break
            if not bk_code:
                # Try searching the full concept list
                for page in range(1, 6):
                    url = (f'{self.BASE_QUOTE}?pn={page}&pz=100&po=0&np=1'
                           f'&fltt=2&invt=2&fid=f12&fs=m:90+t:2&fields=f12,f14')
                    resp = self._get_json(url)
                    for item in (resp.get('data') or {}).get('diff', []):
                        if sector in item['f14']:
                            bk_code = item['f12']
                            break
                    if bk_code: break
            if not bk_code:
                return []
        
        fields = 'f2,f3,f4,f7,f8,f12,f14,f20'
        stocks = []
        page = 1
        while True:
            url = (f'{self.BASE_QUOTE}?pn={page}&pz=500&po=1&np=1'
                   f'&fltt=2&invt=2&fid=f3&fs=b:{bk_code}&fields={fields}')
            resp = self._get_json(url)
            items = (resp.get('data') or {}).get('diff', [])
            if not items: break
            for item in items:
                stocks.append({
                    'code': item['f12'], 'name': item.get('f14', ''),
                    'price': item.get('f2', 0), 'pct': item.get('f3', 0),
                    'amplitude': item.get('f7', 0), 'turnover': item.get('f8', 0),
                    'market_cap': item.get('f20', 0),
                })
            if len(items) < 500: break
            page += 1
            time.sleep(0.05)
        return stocks
    
    def get_sector_rank(self, code: str, sector: str) -> Tuple[int, int]:
        stocks = self.get_sector_stocks(sector)
        stocks.sort(key=lambda x: x['pct'], reverse=True)
        for i, s in enumerate(stocks):
            if s['code'] == code:
                return i + 1, len(stocks)
        return -1, len(stocks)
    
    # ==================== 5. 板块指数K线 ====================
    def get_sector_kline(self, sector: str, days: int = 600) -> List[dict]:
        if sector in CONCEPT_GRADE_MAP:
            bk_code = sector
        else:
            # Look up by name
            bk_code = None
            for sname, code in CONCEPT_GRADE_MAP.items():
                if sector in sname: bk_code = sname; break
            if not bk_code: return []
        
        secid = f'90.{bk_code}'
        url = (f'{self.BASE_KLINE}?secid={secid}&fields1=f1,f2,f3,f4,f5,f6'
               f'&fields2=f51,f52,f53,f54,f55,f56,f57,f58'
               f'&klt=101&fqt=1&end=20500101&lmt={days}')
        resp = self._get_json(url)
        records = []
        for k in (resp.get('data') or {}).get('klines', []):
            parts = k.split(',')
            if len(parts) >= 7:
                o, c, h, l = float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])
                records.append({
                    'date': parts[0], 'open': o, 'close': c, 'high': h, 'low': l,
                    'vol': float(parts[5]), 'amount': float(parts[6]),
                    'amplitude': float(parts[7]) if len(parts)>7 and parts[7]!='-' else 0,
                    'pct': round((c/o-1)*100, 2)
                })
        return records


# ============================================================
# S.C.R.E.E.N. + S-Sector 2.0 筛选器
# ============================================================
class GuilunScreen:
    """归澜 S.C.R.E.E.N. + S-Sector 2.0 筛选引擎"""
    
    def __init__(self, data: GuilunData):
        self.data = data
    
    def screen(self, candidate_codes: List[str] = None, top_n: int = 20) -> List[dict]:
        """
        运行完整 S.C.R.E.E.N. + S-Sector 2.0
        返回通过筛选的股票，按评分排序
        """
        all_stocks = self.data.get_all_stocks()
        passed = []
        
        for s in all_stocks:
            if candidate_codes and s['code'] not in candidate_codes:
                continue
            
            reasons = []
            score = 0
            
            # --- E-Elasticity: 振幅 ≥ 3.5% ---
            ampl = s.get('amplitude', 0)
            if ampl < 3.5:
                continue  # Hard fail
            score += min(ampl, 15) * 3  # Cap at 15%
            reasons.append(f'振幅{ampl:.1f}%')
            
            # --- E-Elasticity: 换手率 ≥ 1% ---
            turnover = s.get('turnover', 0)
            if turnover < 1:
                continue  # Hard fail: zombie
            if 3 <= turnover <= 8:
                score += 10
            elif turnover > 8:
                score += 5
            reasons.append(f'换手{turnover:.1f}%')
            
            # --- E-Elasticity: 市值 ---
            mcap = s.get('market_cap', 0)
            if 100e8 <= mcap <= 500e8:
                score += 10
            elif 50e8 <= mcap < 100e8:
                score += 7
            elif 500e8 < mcap <= 2000e8:
                score += 7
            reasons.append(f'市值{mcap/1e8:.0f}亿')
            
            # --- S-Sector 2.0: 基于概念板块实际归属 ---
            grade, concepts = self.data.classify_stock(s['code'])
            if grade == 'blacklist':
                continue  # Auto-exclude
            score += GRADE_SCORE[grade]
            reasons.append(f'赛道{grade}')
            
            # --- E-Earnings: PE sanity ---
            pe = s.get('pe', 0)
            if pe > 200 or pe < 0:
                continue
            reasons.append(f'PE{pe:.0f}')
            
            # --- Pct bonus: recent strength ---
            pct = s.get('pct', 0)
            if pct > 0:
                score += min(pct, 10) * 0.5
            
            passed.append({
                'code': s['code'], 'name': s['name'],
                'price': s['price'], 'pct': pct,
                'amplitude': ampl, 'turnover': turnover,
                'market_cap': mcap, 'pe': pe,
                'grade': grade, 'concepts': concepts,
                'score': round(score, 1),
                'reasons': '|'.join(reasons)
            })
        
        passed.sort(key=lambda x: x['score'], reverse=True)
        return passed[:top_n] if top_n else passed
    
    def get_by_grade(self, grade: str = 'gold') -> List[dict]:
        """只返回特定等级的股票"""
        all_passed = self.screen(top_n=None)
        return [s for s in all_passed if s['grade'] == grade]


# ============================================================
# 测试入口
# ============================================================
if __name__ == '__main__':
    print("=" * 60)
    print("归澜数据适配层 v2.0 — 东方财富 + S-Sector 2.0 概念分类")
    print("=" * 60)
    
    gd = GuilunData()
    
    # 1. Stock count
    stocks = gd.get_all_stocks()
    print(f"\n✅ 全A股: {len(stocks)}只")
    
    # 2. K-line
    kline = gd.get_kline('600584', 600)
    print(f"✅ 长电科技K线: {len(kline)}条, {kline[0]['date']}~{kline[-1]['date']}")
    
    # 3. S-Sector 2.0 classification test
    print(f"\n📊 S-Sector 2.0 概念分类测试:")
    test_codes = {
        '600584': '长电科技(封测→应黑名单)',
        '603986': '兆易创新(芯片设计→应黄金)',
        '002371': '北方华创(半导体设备→应黄金)',
        '601012': '隆基绿能(光伏→应黑名单)',
        '300750': '宁德时代(锂电池→应白银)',
    }
    for code, desc in test_codes.items():
        grade, concepts = gd.classify_stock(code)
        print(f"  {code} {desc}: → {grade} (板块:{concepts})")
    
    # 4. Full S.C.R.E.E.N.
    print(f"\n🔍 运行完整 S.C.R.E.E.N. + S-Sector 2.0...")
    screen = GuilunScreen(gd)
    candidates = screen.screen(top_n=20)
    print(f"✅ 通过筛选: {len(candidates)}只")
    
    # Count by grade
    from collections import Counter
    grade_counts = Counter(s['grade'] for s in screen.screen(top_n=None)) if hasattr(screen, '_cached_screen') else {}
    
    print(f"\n📊 精选池 Top 10:")
    for s in candidates[:10]:
        concept_short = ','.join(s['concepts'][:3])
        print(f"  {'🥇' if s['grade']=='gold' else '🥈' if s['grade']=='silver' else '🥉'} "
              f"{s['name']:<8}({s['code']}) 评分{s['score']:.0f} | {s['reasons']} | 概念:{concept_short}")
    
    # 5. Gold tier specifically
    gold = screen.get_by_grade('gold')
    print(f"\n🏆 黄金赛道 ({len(gold)}只):")
    for s in gold[:5]:
        print(f"  {s['name']}({s['code']}) {s['price']:.2f} 评分{s['score']:.0f} | {s['reasons']}")
    
    print(f"\n✅ 归澜数据层 v2.0 就绪")

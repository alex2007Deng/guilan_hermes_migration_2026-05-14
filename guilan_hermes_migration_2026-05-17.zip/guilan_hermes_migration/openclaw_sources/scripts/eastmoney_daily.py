#!/usr/bin/env python3
"""
归澜操盘数据 CLI — 东方财富 v2.0 无限制
用法:
  python3 eastmoney_daily.py              # 持仓全数据（实时/收盘）
  python3 eastmoney_daily.py --premarket  # 盘前：隔夜+关键价位
  python3 eastmoney_daily.py --midday     # 午盘速报
  python3 eastmoney_daily.py --close      # 收盘完整复盘
  python3 eastmoney_daily.py --sector      # 板块相对强弱
  python3 eastmoney_daily.py --monitor     # 三监控项快速扫描
"""

import sys, os, json, time, urllib.request, ssl
from datetime import datetime

ssl._create_default_https_context = ssl._create_unverified_context

# ============ 配置 ============
# 当前空仓（长电科技 600584 已于 2026-05-11 全仓清出 @55.01，合计 +2,555.16）
HOLDING = None

WATCHLIST = {
    '605111': {'name': '新洁能', 'buy_zone': '44-45', 'stop': 42.0, 'target1': 47.5, 'target2': 50.5},
}

INDICES = {
    '000001': ('上证指数', '1'),
    '399001': ('深证成指', '0'),
    '399006': ('创业板指', '0'),
    '000688': ('科创50', '1'),
}

SECTORS = {
    'BK1161': '先进封装',
    'BK1036': '半导体',
    'BK0894': '国产芯片',
    'BK1139': '存储芯片',
}

# 策路关键价位
STOP_PROFIT_1 = 49.59   # +8%
STOP_PROFIT_2 = 52.80   # +15%
STOP_LOSS_PRICE = 43.62 # -5%


def fetch_json(url, timeout=10):
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0',
        'Referer': 'http://quote.eastmoney.com/'
    })
    try:
        return json.loads(urllib.request.urlopen(req, timeout=timeout).read())
    except:
        return {}


def get_stock_quote(code, market='1'):
    """获取个股实时行情"""
    secid = f'{market}.{code}'
    url = (f'https://push2.eastmoney.com/api/qt/stock/get?secid={secid}'
           f'&fields=f43,f44,f45,f46,f47,f48,f50,f51,f52,f55,f57,f58,f60,f116,f162,f167,f168,f169,f170,f171')
    resp = fetch_json(url)
    data = resp.get('data', {})
    if not data:
        return None
    
    def p(v): return v / 100 if v else 0
    
    return {
        'code': data.get('f57', code),
        'name': data.get('f58', ''),
        'price': p(data.get('f43', 0)),
        'high': p(data.get('f44', 0)),
        'low': p(data.get('f45', 0)),
        'open': p(data.get('f46', 0)),
        'prev_close': p(data.get('f60', 0)),
        'change': p(data.get('f169', 0)),
        'pct': p(data.get('f170', 0)),
        'amplitude': p(data.get('f168', 0)),
        'turnover': p(data.get('f167', 0)),
        'vol_hands': data.get('f47', 0),
        'amount': data.get('f48', 0),
        'mcap': data.get('f116', 0),
        'pe': p(data.get('f162', 0)),
        'vol_ratio': p(data.get('f50', 0)),
        'limit_up': p(data.get('f51', 0)),
        'limit_down': p(data.get('f52', 0)),
    }


def get_sector_quote(bk_code):
    """获取板块指数实时行情"""
    secid = f'90.{bk_code}'
    url = (f'https://push2.eastmoney.com/api/qt/stock/get?secid={secid}'
           f'&fields=f43,f44,f45,f46,f57,f58,f60,f170,f168')
    resp = fetch_json(url)
    data = resp.get('data', {})
    if not data:
        return None
    
    def p(v): return v / 100 if v else 0
    
    return {
        'code': data.get('f57', bk_code),
        'name': data.get('f58', ''),
        'price': p(data.get('f43', 0)),
        'high': p(data.get('f44', 0)),
        'low': p(data.get('f45', 0)),
        'open': p(data.get('f46', 0)),
        'prev_close': p(data.get('f60', 0)),
        'pct': p(data.get('f170', 0)),
        'amplitude': p(data.get('f168', 0)),
    }


def get_fund_flow(code, market='1', days=5):
    """获取个股资金流向"""
    # East Money fund flow API
    secid = f'{market}.{code}'
    url = (f'https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get?'
           f'secid={secid}&fields1=f1,f2,f3&fields2=f51,f52,f53,f54,f55,f56,f57'
           f'&lmt={days}&klt=101')
    resp = fetch_json(url)
    klines = (resp.get('data') or {}).get('klines', [])
    
    total_main_in = 0
    flows = []
    for k in klines:
        parts = k.split(',')
        if len(parts) >= 7:
            main_net = float(parts[1]) if parts[1] != '-' else 0
            total_main_in += main_net
            flows.append({
                'date': parts[0],
                'main_net': main_net,
                'retail_net': float(parts[5]) if parts[5] != '-' and len(parts) > 5 else 0,
            })
    
    return {
        'period_days': days,
        'total_main_net': total_main_in,
        'daily': flows,
    }


def get_indices():
    """获取各大指数"""
    results = []
    for code, (name, market) in INDICES.items():
        q = get_stock_quote(code, market)
        if q:
            q['name'] = name  # override
            results.append(q)
    return results


def format_billion(amount):
    if not amount: return '-'
    yi = abs(amount) / 1e8
    return f'{amount/1e8:+.2f}亿'


def print_holding(quote):
    """打印持仓详情"""
    cost = HOLDING['cost']
    shares = HOLDING['shares']
    floating = (quote['price'] - cost) * shares
    floating_pct = (quote['price'] / cost - 1) * 100
    
    print(f"\n{'='*55}")
    print(f"  {quote['name']} ({quote['code']}) | {datetime.now().strftime('%m-%d %H:%M')}")
    print(f"{'='*55}")
    print(f"  现价: {quote['price']:.2f}  |  涨跌: {quote['change']:+.2f} ({quote['pct']:+.2f}%)")
    print(f"  今开: {quote['open']:.2f}  |  最高: {quote['high']:.2f}  |  最低: {quote['low']:.2f}")
    print(f"  昨收: {quote['prev_close']:.2f}  |  振幅: {quote['amplitude']:.1f}%  |  换手: {quote['turnover']:.1f}%")
    print(f"  成交: {format_billion(quote['amount'])}  |  量比: {quote['vol_ratio']:.2f}")
    if quote['pe']:
        print(f"  市值: {quote['mcap']/1e8:.0f}亿  |  PE: {quote['pe']:.1f}")
    print(f"  {'─'*51}")
    print(f"  持仓: {shares}股  |  成本: {cost:.4f}  |  总成本: {HOLDING['total_cost']:,.0f}")
    print(f"  浮盈: {floating:+,.0f}元 ({floating_pct:+.2f}%)")
    
    # 关键价位
    print(f"  {'─'*51}")
    print(f"  止盈一: {STOP_PROFIT_1:.2f} | 止盈二: {STOP_PROFIT_2:.2f} | 止损: {STOP_LOSS_PRICE:.2f}")
    dist_sp1 = (STOP_PROFIT_1 / quote['price'] - 1) * 100
    dist_sp2 = (STOP_PROFIT_2 / quote['price'] - 1) * 100
    dist_sl = (STOP_LOSS_PRICE / quote['price'] - 1) * 100
    
    sp1_status = '✅ 已突破' if quote['price'] >= STOP_PROFIT_1 else f'差 {dist_sp1:+.2f}%'
    sp2_status = '✅ 已突破' if quote['price'] >= STOP_PROFIT_2 else f'差 {dist_sp2:+.2f}%'
    sl_status = f'距 {dist_sl:+.2f}%'
    
    print(f"  止盈一状态: {sp1_status}")
    print(f"  止盈二状态: {sp2_status}")
    print(f"  止损状态: {sl_status}")
    
    return floating, floating_pct


def print_indices(indices):
    """打印指数一览"""
    print(f"\n{'─'*55}")
    print(f"  📈 指数一览")
    print(f"{'─'*55}")
    for idx in indices:
        print(f"  {idx['name']:<8} {idx['price']:>10.2f}  {idx['pct']:>+7.2f}%")


def print_sectors(holding_pct):
    """打印板块对比"""
    print(f"\n{'─'*55}")
    print(f"  🏭 板块 vs 个股")
    print(f"{'─'*55}")
    
    for bk_code, name in SECTORS.items():
        sq = get_sector_quote(bk_code)
        if sq:
            diff = holding_pct - sq['pct']
            signal = '🔥跑赢' if diff > 0.5 else ('🟡平' if diff > -0.5 else '🔴跑输')
            print(f"  {name:<10} {sq['pct']:>+7.2f}%  |  长电 {holding_pct:>+7.2f}%  |  {signal} ({diff:+.1f}pp)")


def print_fund_flow():
    """打印资金流向"""
    ff = get_fund_flow(HOLDING['code'], '1', 5)
    if not ff['daily']:
        return
    
    print(f"\n{'─'*55}")
    print(f"  💰 近{ff['period_days']}日资金流向")
    print(f"{'─'*55}")
    print(f"  主力累计净流入: {ff['total_main_net']/1e4:+.0f}万")
    for d in ff['daily']:
        net = d['main_net'] / 1e4
        bar = '█' * max(0, min(10, int(abs(net) / 5000))) 
        sign = '🔴' if net < 0 else '🟢'
        print(f"  {d['date']}  {sign} {net:>+8.0f}万  {bar}")


def print_monitor(holding_quote, indices):
    """三监控项扫描"""
    print(f"\n{'='*55}")
    print(f"  📋 体系迭代监控（三必查）")
    print(f"{'='*55}")
    
    # ① 黑名单赛道
    print(f"\n  ① 黑名单赛道回撤收窄")
    for bk_code, name in SECTORS.items():
        sq = get_sector_quote(bk_code)
        if sq:
            trend = '🟢 走强' if sq['pct'] > 0 else ('🟡 平盘' if sq['pct'] > -0.5 else '🔴 走弱')
            print(f"    {name}: {sq['pct']:+.2f}% {trend}")
    print(f"    结论: 先进封装持续走强，黑名单细分暂维持")
    
    # ② 仓位上限
    sh = next((i for i in indices if i['code'] == '000001'), None)
    if sh:
        print(f"\n  ② 仓位上限动态调整")
        print(f"    上证: {sh['price']:.2f} | 昨收: {sh['prev_close']:.2f}")
        # Simplified MA check (would need K-line for precise values)
        from collections import deque
        # Quick MA proxy: if index above 4000, trend up
        state = '🟢 上升趋势' if sh['price'] > 4000 else '🟡 震荡/不确定'
        print(f"    市场状态: {state}")
        print(f"    当前仓位: {HOLDING['shares']}股/{HOLDING['shares']*holding_quote['price']:,.0f}元")
    
    # ③ 熊市预警
    print(f"\n  ③ 熊市信号扫描")
    print(f"    暂无北向/两融数据接入，核心观察:")
    for idx in indices:
        signal = '✅' if idx['pct'] > -0.5 else ('🟡 关注' if idx['pct'] > -1.5 else '🔴 预警')
        print(f"    {idx['name']}: {idx['pct']:+.2f}% {signal}")
    
    # 跌停扫描
    print(f"    跌停情况: 需盘中数据确认")


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else ''
    
    if mode == '--premarket':
        print("📊 盘前分析")
        print("(隔夜外盘数据接入中...)")
        # Would fetch overnight US/HK data
    
    # Default: full data
    print(f"\n{'█'*55}")
    print(f"  归澜操盘数据 · 东方财富 v2.0")
    print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'█'*55}")
    
    # 1. 持仓
    if HOLDING:
        quote = get_stock_quote(HOLDING['code'], '1')
        if not quote:
            print("❌ 无法获取行情数据")
            return
        floating, floating_pct = print_holding(quote)
    else:
        quote = None
        floating = 0
        floating_pct = 0
        print(f"\n  💤 当前空仓 — 可用资金约 20,920 元")
        if WATCHLIST:
            print(f"  👀 关注列表:")
            for code, info in WATCHLIST.items():
                wq = get_stock_quote(code, '1')
                if wq:
                    print(f"     {info['name']} {code}  现价 {wq['price']:.2f}  买入区 {info['buy_zone']}")
    
    # 2. 指数
    indices = get_indices()
    print_indices(indices)
    
    # 3. 板块对比
    print_sectors(quote['pct'] if quote else 0)
    
    # 4. 资金流向
    if mode in ('', '--close') and HOLDING:
        print_fund_flow()
    
    # 5. 三监控
    if mode in ('', '--monitor', '--close'):
        print_monitor(quote, indices)
    
    # 6. 操作建议
    print(f"\n{'='*55}")
    print(f"  🎯 操作建议")
    print(f"{'='*55}")
    if not HOLDING:
        print(f"  💤 空仓等待 | 🏁 长电合计 +2,555.16 已入账")
        if WATCHLIST:
            for code, info in WATCHLIST.items():
                wq = get_stock_quote(code, '1')
                if wq:
                    dist = (wq['price'] - float(info['buy_zone'].split('-')[1])) / float(info['buy_zone'].split('-')[1]) * 100
                    print(f"  👀 {info['name']} {code}: 现价 {wq['price']:.2f}，买入区 {info['buy_zone']}，距买入区 {dist:+.1f}%")
    elif quote['price'] >= STOP_PROFIT_1:
        shares_to_sell = HOLDING['shares'] // 2
        expected = shares_to_sell * quote['price']
        print(f"  ✅ 止盈一已触发！建议卖出 {shares_to_sell}股")
        print(f"  预计回收: {expected:,.0f}元")
        print(f"  剩余 {HOLDING['shares']-shares_to_sell}股 目标止盈二 {STOP_PROFIT_2}")
    elif floating_pct > 1:
        print(f"  🟢 浮盈 {floating_pct:+.1f}%，继续持有")
        print(f"  距止盈一 {quote['price']/STOP_PROFIT_1*100-100:.2f}%")
    elif floating_pct < 0:
        print(f"  🔴 浮亏 {floating_pct:+.1f}%")
        print(f"  距止损 {quote['price']/STOP_LOSS_PRICE*100-100:.2f}%")
    
    print()


if __name__ == '__main__':
    main()

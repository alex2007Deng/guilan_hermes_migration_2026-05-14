# Hermes 默认模型重启回 Claude 的修复

更新时间：2026-05-14

## 结论

Zeabur 日志显示 Hermes 启动时会重新整理 `/opt/data`。删掉挂载卷后，Web UI 里手动改成 DeepSeek 的配置可能只存在于运行中的临时文件里；服务一重启，镜像默认配置又恢复为 OpenRouter Claude。

修复思路：不要依赖 UI 里手动选择模型，而是在 Zeabur 服务“环境变量”中把 DeepSeek 固化为启动默认模型。

## 必填环境变量

在 Zeabur `hermes-agent` 服务的“环境变量”中设置：

```text
DEEPSEEK_API_KEY=你的 DeepSeek 密钥
HERMES_INFERENCE_PROVIDER=deepseek
HERMES_INFERENCE_MODEL=deepseek-v4-pro
```

同时保留 OpenAI 兼容变量，兼容不同启动路径：

```text
OPENAI_API_KEY=你的 DeepSeek 密钥
OPENAI_BASE_URL=https://api.deepseek.com
OPENAI_MODEL=deepseek-v4-pro
```

如果环境变量里存在这些值，请改掉或删除：

```text
OPENROUTER_MODEL=claude...
DEFAULT_MODEL=claude...
MODEL=claude...
ANTHROPIC_MODEL=claude...
```

`OPENROUTER_API_KEY` 可以暂时保留，但不应作为默认模型入口。

## 验证

重启 Hermes 后，在 Zeabur 终端执行：

```bash
cd /opt/hermes/guilan
scripts/check_hermes_model_env.sh
```

通过标准：

- 能看到 `HERMES_INFERENCE_PROVIDER=deepseek`
- 能看到 `HERMES_INFERENCE_MODEL=deepseek-v4-pro`
- 不能再看到 `DEFAULT_MODEL=claude...` 或 `MODEL=claude...`

## 如果仍然恢复 Claude

说明 Hermes 的启动配置文件覆盖了环境变量。进入终端执行：

```bash
cd /opt/hermes
find /opt/hermes /opt/data "$HOME" -maxdepth 3 \( -name '.env' -o -name '*config*' -o -name '*.yaml' -o -name '*.yml' \) 2>/dev/null | sort
```

找到含 `openrouter` 或 `claude` 的配置文件后，将默认 provider/model 改为：

```text
provider: deepseek
model: deepseek-v4-pro
```

真实密钥仍然只放环境变量，不写入配置文件。

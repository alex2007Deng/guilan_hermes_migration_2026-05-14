# Hermes + Telegram 部署步骤

> 如果 Zeabur 服务刚经历删卷或崩溃恢复，先看 `ZEABUR_REINSTALL_CHECKLIST.md`。

## 1. 上传目录

把整个 `guilan_hermes_migration` 目录上传到 Hermes 服务，例如：

```text
/opt/hermes/guilan
```

如果上传的是 zip，终端执行：

```bash
cd /opt/hermes
python3 -m zipfile -e guilan_hermes_migration_2026-05-14.zip .
rm -rf guilan
mv guilan_hermes_migration guilan
chmod +x /opt/hermes/guilan/scripts/*.sh
```

## 2. 设置环境变量

在 Hermes/Zeabur 环境变量里设置：

```text
DEEPSEEK_API_KEY=你的 DeepSeek 密钥
HERMES_INFERENCE_PROVIDER=deepseek
HERMES_INFERENCE_MODEL=deepseek-v4-pro
HERMES_MODEL=deepseek-v4-pro
LLM_PROVIDER=deepseek
LLM_MODEL=deepseek-v4-pro
OPENAI_API_KEY=你的 DeepSeek 密钥
OPENAI_BASE_URL=https://api.deepseek.com
OPENAI_MODEL=deepseek-v4-pro
GS_API_KEY=你的国信key
GUILAN_PUSH_CHANNEL=telegram
GUILAN_ENABLE_PUSH=1
TELEGRAM_BOT_TOKEN=你的 Telegram Bot Token
TELEGRAM_HOME_CHANNEL=你的 Telegram chat_id
```

如果 Hermes 重启后恢复为 OpenRouter Claude，先按 `HERMES_DEEPSEEK_MODEL_FIX.md` 清理 `OPENROUTER_MODEL`、`DEFAULT_MODEL` 或 `MODEL` 中的 Claude 默认值。

如果国信暂时不可用，归澜仍会自动使用东方财富和新浪兜底。

国信官网的 Skills 面向 OpenClaw 兼容环境。Hermes 不一定会原生调用这些 OpenClaw Skills，所以本包采取两层迁移：

- 原样备份：`openclaw_sources/skills/gs-*`
- 运行层适配：`src/guilan_market.py` 直接调用国信/东方财富/新浪接口

需要尝试把 OpenClaw Skills 放进 Hermes 时可执行：

```bash
cd /opt/hermes/guilan
scripts/install_openclaw_skills_to_hermes.sh
```

Telegram 网关提示 `No home channel is set` 时，在 Telegram 与机器人对话框里发送：

```text
/sethome
```

## 3. 加载系统提示词

Hermes 的归澜 Agent 使用：

```text
prompts/guilan_hermes_system_prompt.md
```

## 4. 配置定时任务

建议五个固定任务：

```bash
/opt/hermes/guilan/scripts/run_guilan.sh premarket --push
/opt/hermes/guilan/scripts/run_guilan.sh open --push
/opt/hermes/guilan/scripts/run_guilan.sh midday --push
/opt/hermes/guilan/scripts/run_guilan.sh tail --push
/opt/hermes/guilan/scripts/run_guilan.sh close --push
```

时间：

- 08:50 盘前
- 09:35 开盘确认
- 11:30 午盘
- 14:45 尾盘
- 15:15 收盘

## 5. 验证

```bash
cd /opt/hermes/guilan
scripts/check_hermes_model_env.sh
scripts/run_guilan.sh health
scripts/run_guilan.sh scan
scripts/run_guilan.sh scan --push
```

验证通过的标准：

- `health` 返回至少一个行情源成功。
- `scan` 输出新洁能买点判断。
- `scan --push` 能在 Telegram 收到归澜提醒。

## 6. 换股流程

换股时只改：

```text
config/guilan_state.json
```

更新字段：

- `watchlist[0].code`
- `watchlist[0].name`
- `entry_zone`
- `stop_loss`
- `take_profit_1`
- `take_profit_2`
- `planned_shares`

不要改系统提示词来换股。股票状态应由配置文件管理，提示词只保留归澜人格和纪律。

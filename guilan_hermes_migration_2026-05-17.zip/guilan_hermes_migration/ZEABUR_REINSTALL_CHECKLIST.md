# Zeabur Hermes 重装与归澜恢复清单

更新时间：2026-05-14

这份清单用于 Hermes 服务崩溃、删卷、重建后恢复“归澜”。

## 0. 关键原则

- 不再把卷挂到 `/opt/data`。之前崩溃原因是 `/opt/data/.env` 权限错误。
- 归澜运行目录建议放在 `/opt/hermes/guilan`。
- 真实密钥只放 Zeabur 环境变量，不写入知识库、提示词或代码。
- 先恢复 Hermes 本体，再恢复 Telegram，再恢复归澜自动化。

## 1. 先确认 Hermes 服务能启动

进入 Zeabur 的 Hermes 服务终端，执行：

```bash
cd /opt/hermes
.venv/bin/python ./hermes --help
```

如果提示缺少 `yaml`，先执行：

```bash
cd /opt/hermes
.venv/bin/pip install pyyaml
```

然后重新测试：

```bash
cd /opt/hermes
.venv/bin/python ./hermes --help
```

## 2. 配置模型环境变量

在 Zeabur 服务的“环境变量”里配置模型。不要只在 Hermes UI 中手动切换模型；删卷后 UI 配置会随重启丢失，容易恢复为 OpenRouter Claude。

DeepSeek 推荐配置：

```text
DEEPSEEK_API_KEY=你的 DeepSeek 密钥
HERMES_INFERENCE_PROVIDER=deepseek
HERMES_INFERENCE_MODEL=deepseek-v4-pro
```

同时设置 OpenAI 兼容变量作为兜底：

```text
OPENAI_API_KEY=你的模型密钥
OPENAI_BASE_URL=https://api.deepseek.com
OPENAI_MODEL=deepseek-v4-pro
```

如果存在 `OPENROUTER_MODEL=claude...`、`DEFAULT_MODEL=claude...`、`MODEL=claude...`，请改为 `deepseek-v4-pro` 或删除。

保存环境变量后，重启 Hermes 服务。

## 3. 配置 Telegram Bot 网关

进入终端：

```bash
cd /opt/hermes
.venv/bin/python ./hermes gateway setup
```

选择：

```text
Telegram
```

填入 Telegram Bot Token。如果 Telegram 已能收到 Hermes 回复，只需在 Telegram 对话中发送：

```text
/sethome
```

这会把当前聊天设置为 Hermes 的 home channel，用于接收定时任务和跨平台消息。

如果重启后服务再次崩溃，第一时间看日志，重点检查是否仍有 `/opt/data/.env Permission denied`。

## 4. 上传归澜包

把本地压缩包上传到 Hermes 服务：

```text
/Users/alex/Documents/WPS/projects/honglitay_ai/量化/策略/guilan_hermes_migration_2026-05-14.zip
```

建议上传到：

```text
/opt/hermes/
```

然后在终端解压：

```bash
cd /opt/hermes
python3 -m zipfile -e guilan_hermes_migration_2026-05-14.zip .
mv guilan_hermes_migration guilan
chmod +x /opt/hermes/guilan/scripts/*.sh
```

## 5. 设置归澜环境变量

在 Zeabur 环境变量中加入：

```text
GS_API_KEY=你的国信key
S_API_KEY=你的国信key
GUILAN_PUSH_CHANNEL=telegram
GUILAN_ENABLE_PUSH=1
TELEGRAM_BOT_TOKEN=你的 Telegram Bot Token
TELEGRAM_HOME_CHANNEL=你的 Telegram chat_id
```

如果暂时只想写日志、不推送，先设：

```text
GUILAN_ENABLE_PUSH=0
```

这样归澜只写日志、不推 Telegram，避免因为推送接口未通导致任务失败。

## 6. 验证归澜

终端执行：

```bash
cd /opt/hermes/guilan
scripts/check_hermes_model_env.sh
scripts/run_guilan.sh health
scripts/run_guilan.sh scan
```

通过标准：

- `health` 至少有一个数据源可用。
- `scan` 能输出新洁能 `605111` 的买点判断。
- 如果是交易日盘中，实时行情优先；如果休市，允许使用最近 K 线收盘数据。

## 7. 配置自动化

建议定时任务：

```text
08:50 盘前
09:35 开盘确认
11:30 午盘
14:45 尾盘
15:15 收盘
```

对应命令：

```bash
/opt/hermes/guilan/scripts/run_guilan.sh premarket --push
/opt/hermes/guilan/scripts/run_guilan.sh open --push
/opt/hermes/guilan/scripts/run_guilan.sh midday --push
/opt/hermes/guilan/scripts/run_guilan.sh tail --push
/opt/hermes/guilan/scripts/run_guilan.sh close --push
```

## 8. 当前归澜状态

- 当前持仓：空仓。
- 已完成交易：长电科技 `600584` 已清仓，合计盈利 `+2555.16`。
- 当前候选：新洁能 `605111`。
- 买入区：`44~45`。
- 止损：`42.00`。
- 止盈一：`47.5~48`。
- 止盈二：`50.5~52`。
- 首仓计划：`100股`。

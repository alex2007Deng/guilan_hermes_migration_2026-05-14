#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="${HERMES_SKILLS_DIR:-/opt/hermes/skills}"

if [[ ! -d "$TARGET" ]]; then
  echo "Hermes skills directory not found: $TARGET"
  exit 1
fi

for skill in \
  trading-strategy \
  gs-stock-market-query \
  gs-stock-financial-query \
  gs-economy-query \
  gs-smart-stock-picking \
  gs-fund-compare \
  gs-etf-filter
do
  src="$ROOT/openclaw_sources/skills/$skill"
  dst="$TARGET/$skill"
  if [[ -d "$src" ]]; then
    rm -rf "$dst"
    cp -a "$src" "$dst"
    echo "installed $skill -> $dst"
  fi
done

echo
echo "说明：这些是 OpenClaw 兼容 skills 的原样备份安装。"
echo "归澜自动化实际取数优先使用 /opt/hermes/guilan/src/guilan_market.py，不依赖 Hermes 原生识别这些 skills。"

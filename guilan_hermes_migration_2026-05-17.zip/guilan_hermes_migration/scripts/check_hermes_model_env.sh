#!/usr/bin/env bash
set -euo pipefail

echo "== Hermes model environment =="
env | sort | grep -E '^(HERMES_INFERENCE_PROVIDER|HERMES_INFERENCE_MODEL|HERMES_MODEL|LLM_PROVIDER|LLM_MODEL|DEEPSEEK_API_KEY|OPENAI_BASE_URL|OPENAI_MODEL|OPENAI_API_KEY|OPENROUTER_API_KEY|OPENROUTER_MODEL|ANTHROPIC_API_KEY|MODEL|DEFAULT_MODEL|TELEGRAM_HOME_CHANNEL|TELEGRAM_CHAT_ID|GUILAN_PUSH_CHANNEL|GUILAN_ENABLE_PUSH)=' \
  | sed -E 's/(API_KEY|TOKEN|SECRET)=.*/\1=***MASKED***/' || true

echo
echo "== Known config files =="
find /opt/hermes /opt/data "${HOME:-/home/hermes}" -maxdepth 3 \
  \( -name '.env' -o -name '*config*' -o -name '*.yaml' -o -name '*.yml' -o -name '*.json' \) \
  2>/dev/null | sort | head -200 || true

echo
echo "== Model references, first 120 lines =="
grep -R "openrouter\|claude\|deepseek\|default_model\|HERMES_INFERENCE\|OPENAI_MODEL" \
  -n /opt/hermes /opt/data 2>/dev/null | head -120 || true

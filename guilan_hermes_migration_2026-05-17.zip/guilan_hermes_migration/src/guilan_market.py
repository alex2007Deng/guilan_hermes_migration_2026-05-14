#!/usr/bin/env python3
"""Market data router for Guilan.

Priority:
1. Guosen API when configured.
2. Eastmoney for quote, K-line, all-A scan, fund flow.
3. Sina as quote fallback.
"""

from __future__ import annotations

import json
import os
import ssl
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any


ssl._create_default_https_context = ssl._create_unverified_context


@dataclass
class MarketRouter:
    timeout: int = int(os.environ.get("GUILAN_HTTP_TIMEOUT", "12"))

    def code(self, code: str) -> str:
        return str(code or "").strip().lower().replace("sh", "").replace("sz", "")

    def set_code(self, code: str) -> int:
        c = self.code(code)
        if c.startswith(("6", "5", "9")):
            return 1
        if c.startswith(("8", "4")):
            return 2
        return 0

    def secid(self, code: str) -> str:
        c = self.code(code)
        if c == "000001":
            return "1.000001"
        if c in ("399001", "399006"):
            return "0." + c
        return ("1." if c.startswith(("6", "5", "9")) else "0.") + c

    def sina_symbol(self, code: str) -> str:
        c = self.code(code)
        prefix = "sh" if c.startswith(("6", "5", "9")) or c == "000001" else "sz"
        return prefix + c

    def num(self, value: Any, scale: float = 1.0) -> float | None | Any:
        if value in (None, "-", ""):
            return None
        try:
            return round(float(value) / scale, 4)
        except Exception:
            return value

    def adaptive(self, value: Any) -> float | None | Any:
        if value in (None, "-", ""):
            return None
        try:
            v = float(value)
            return round(v / 100, 4) if abs(v) > 1000 else round(v, 4)
        except Exception:
            return value

    def text(self, url: str, encoding: str = "utf-8", referer: str = "https://quote.eastmoney.com/") -> str:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Referer": referer})
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            return resp.read().decode(encoding, errors="ignore")

    def json(self, url: str, referer: str = "https://quote.eastmoney.com/") -> dict[str, Any]:
        return json.loads(self.text(url, "utf-8", referer))

    def attempt(self, source: str, fn):
        try:
            return {"ok": True, "source": source, "data": fn()}
        except Exception as e:
            return {"ok": False, "source": source, "error": str(e)}

    def guosen(self, path: str, params: dict[str, Any]) -> dict[str, Any]:
        key = os.environ.get("GS_API_KEY") or os.environ.get("S_API_KEY") or ""
        if not key:
            return {"ok": False, "source": "Guosen", "error": "GS_API_KEY is not set"}
        query = dict(params)
        query["softName"] = "agent_skills"
        query["apiKey"] = key
        url = "https://dgzt.guosen.com.cn/skills" + path + "?" + urllib.parse.urlencode(query)
        return self.json(url, "https://www.guosen.com.cn/")

    def eastmoney_quote(self, code: str) -> dict[str, Any]:
        fields = "f43,f44,f45,f46,f47,f48,f50,f57,f58,f60,f86,f116,f162,f167,f168,f169,f170,f171"
        url = "https://push2.eastmoney.com/api/qt/stock/get?" + urllib.parse.urlencode(
            {"secid": self.secid(code), "fields": fields}
        )
        data = (self.json(url).get("data") or {})
        if not data:
            raise RuntimeError("empty Eastmoney quote")
        return {
            "code": data.get("f57") or self.code(code),
            "name": data.get("f58") or "",
            "price": self.num(data.get("f43"), 100),
            "open": self.num(data.get("f46"), 100),
            "high": self.num(data.get("f44"), 100),
            "low": self.num(data.get("f45"), 100),
            "prev_close": self.num(data.get("f60"), 100),
            "pct_change": self.num(data.get("f170"), 100),
            "turnover": self.num(data.get("f168"), 100),
            "amount_yuan": data.get("f48"),
            "vol_ratio": self.num(data.get("f50"), 100),
            "pe": self.num(data.get("f162"), 100),
            "timestamp": data.get("f86"),
            "source": "Eastmoney",
        }

    def sina_quote(self, code: str) -> dict[str, Any]:
        raw = self.text("https://hq.sinajs.cn/list=" + self.sina_symbol(code), "gbk", "https://finance.sina.com.cn/")
        part = raw.split('"')
        if len(part) < 2 or not part[1]:
            raise RuntimeError("empty Sina quote")
        values = part[1].split(",")
        price = self.num(values[3]) if len(values) > 3 else None
        prev = self.num(values[2]) if len(values) > 2 else None
        out = {
            "code": self.code(code),
            "name": values[0] if values else "",
            "open": self.num(values[1]) if len(values) > 1 else None,
            "prev_close": prev,
            "price": price,
            "high": self.num(values[4]) if len(values) > 4 else None,
            "low": self.num(values[5]) if len(values) > 5 else None,
            "date": values[30] if len(values) > 30 else None,
            "time": values[31] if len(values) > 31 else None,
            "source": "Sina",
        }
        if price is not None and prev:
            out["pct_change"] = round((price - prev) / prev * 100, 4)
        return out

    def quote(self, code: str) -> dict[str, Any]:
        out = {"code": self.code(code), "attempts": []}
        out["attempts"].append(
            self.attempt(
                "Guosen",
                lambda: self.guosen(
                    "/gsnews/market/agentbot/queryHQInfo/1.0",
                    {"code": self.code(code), "setCode": self.set_code(code), "target": 0},
                ),
            )
        )
        for name, fn in (("Eastmoney", lambda: self.eastmoney_quote(code)), ("Sina", lambda: self.sina_quote(code))):
            attempt = self.attempt(name, fn)
            out["attempts"].append(attempt)
            if attempt["ok"]:
                out["quote"] = attempt["data"]
                break
        return out

    def kline(self, code: str, days: int = 90) -> dict[str, Any]:
        url = "https://push2his.eastmoney.com/api/qt/stock/kline/get?" + urllib.parse.urlencode(
            {
                "secid": self.secid(code),
                "klt": "101",
                "fqt": "1",
                "end": "20500101",
                "lmt": str(int(days)),
                "fields1": "f1,f2,f3,f4,f5,f6",
                "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
            }
        )
        rows = (self.json(url).get("data") or {}).get("klines", [])
        records = []
        closes = []
        for row in rows:
            parts = row.split(",")
            if len(parts) >= 7:
                close = self.num(parts[2])
                closes.append(close)
                records.append(
                    {
                        "date": parts[0],
                        "open": self.num(parts[1]),
                        "close": close,
                        "high": self.num(parts[3]),
                        "low": self.num(parts[4]),
                        "amount_yuan": self.num(parts[6]),
                    }
                )
        if not records:
            raise RuntimeError("empty Eastmoney kline")
        return {
            "code": self.code(code),
            "latest": records[-1],
            "ma20": round(sum(closes[-20:]) / 20, 4) if len(closes) >= 20 else None,
            "ma60": round(sum(closes[-60:]) / 60, 4) if len(closes) >= 60 else None,
            "recent_5": records[-5:],
            "source": "Eastmoney K-line",
        }

    def fund_flow(self, code: str, days: int = 5) -> dict[str, Any]:
        url = "https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get?" + urllib.parse.urlencode(
            {
                "secid": self.secid(code),
                "fields1": "f1,f2,f3",
                "fields2": "f51,f52,f53,f54,f55,f56,f57",
                "lmt": str(int(days)),
                "klt": "101",
            }
        )
        rows = (self.json(url).get("data") or {}).get("klines", [])
        total = 0.0
        daily = []
        for row in rows:
            parts = row.split(",")
            if len(parts) >= 2:
                main = float(parts[1]) if parts[1] != "-" else 0.0
                total += main
                daily.append({"date": parts[0], "main_net_yuan": main})
        return {"code": self.code(code), "days": days, "total_main_net_yuan": total, "daily": daily, "source": "Eastmoney fund flow"}

    def health_check(self) -> dict[str, Any]:
        return {
            "checked_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "GS_API_KEY_loaded": bool(os.environ.get("GS_API_KEY") or os.environ.get("S_API_KEY")),
            "checks": [
                self.attempt("Guosen", lambda: self.guosen("/gsnews/market/agentbot/queryHQInfo/1.0", {"code": "600584", "setCode": 1, "target": 0})),
                self.attempt("Eastmoney quote", lambda: self.eastmoney_quote("600584")),
                self.attempt("Sina quote", lambda: self.sina_quote("600584")),
                self.attempt("Eastmoney kline", lambda: self.kline("600584", 90)),
            ],
        }


def dumps(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Guilan market data router")
    parser.add_argument("command", choices=["health", "quote", "kline", "flow"])
    parser.add_argument("--code", default="605111")
    parser.add_argument("--days", type=int, default=90)
    args = parser.parse_args()

    router = MarketRouter()
    if args.command == "health":
        print(dumps(router.health_check()))
    elif args.command == "quote":
        print(dumps(router.quote(args.code)))
    elif args.command == "kline":
        print(dumps(router.kline(args.code, args.days)))
    elif args.command == "flow":
        print(dumps(router.fund_flow(args.code, args.days)))

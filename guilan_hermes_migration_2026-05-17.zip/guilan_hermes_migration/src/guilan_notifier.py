#!/usr/bin/env python3
"""Notification adapters for Guilan Hermes migration."""

from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any


@dataclass
class TelegramNotifier:
    bot_token: str
    chat_id: str
    timeout: int = 10

    @classmethod
    def from_env(cls) -> "TelegramNotifier":
        return cls(
            bot_token=os.environ.get("TELEGRAM_BOT_TOKEN", ""),
            chat_id=os.environ.get("TELEGRAM_HOME_CHANNEL", "") or os.environ.get("TELEGRAM_CHAT_ID", ""),
        )

    def send(self, message: str) -> dict[str, Any]:
        if not self.bot_token:
            return {"ok": False, "error": "TELEGRAM_BOT_TOKEN is not set"}
        if not self.chat_id:
            return {"ok": False, "error": "TELEGRAM_HOME_CHANNEL or TELEGRAM_CHAT_ID is not set"}
        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        body = urllib.parse.urlencode(
            {
                "chat_id": self.chat_id,
                "text": message,
                "disable_web_page_preview": "true",
            }
        ).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                text = resp.read().decode("utf-8", errors="ignore")
            try:
                data = json.loads(text)
            except Exception:
                data = {"raw": text}
            return {"ok": bool(data.get("ok", True)), "status": getattr(resp, "status", None), "response": data}
        except Exception as e:
            return {"ok": False, "error": str(e)}


def notifier_from_env() -> TelegramNotifier:
    channel = os.environ.get("GUILAN_PUSH_CHANNEL", "telegram").strip().lower()
    if channel != "telegram":
        return TelegramNotifier(
            bot_token="",
            chat_id="",
        )
    return TelegramNotifier.from_env()

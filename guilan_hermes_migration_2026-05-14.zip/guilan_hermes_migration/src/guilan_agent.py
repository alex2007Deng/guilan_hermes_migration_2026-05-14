#!/usr/bin/env python3
"""Hermes-side Guilan agent runner.

This script is intentionally deterministic: it reads the local state file,
pulls market data, applies Guilan guardrails, writes a signal log, and can
optionally push the message to Telegram.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from guilan_market import MarketRouter, dumps
from guilan_notifier import notifier_from_env


ROOT = Path(__file__).resolve().parents[1]
STATE_FILE = ROOT / "config" / "guilan_state.json"
SIGNAL_LOG = ROOT / "logs" / "signals.jsonl"
JOURNAL_FILE = ROOT / "state" / "trading_journal_runtime.md"


def load_state() -> dict[str, Any]:
    return json.loads(STATE_FILE.read_text(encoding="utf-8"))


def save_signal(signal: dict[str, Any]) -> None:
    SIGNAL_LOG.parent.mkdir(parents=True, exist_ok=True)
    with SIGNAL_LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(signal, ensure_ascii=False) + "\n")


def latest_price(bundle: dict[str, Any], kline: dict[str, Any] | None = None) -> float | None:
    quote = bundle.get("quote") or {}
    price = quote.get("price")
    if price is not None:
        return float(price)
    if kline:
        latest = kline.get("latest") or {}
        close = latest.get("close")
        if close is not None:
            return float(close)
    return None


def candidate_watch(router: MarketRouter, state: dict[str, Any]) -> dict[str, Any]:
    candidate = state["watchlist"][0]
    code = candidate["code"]
    quote_bundle = router.quote(code)
    kline_attempt = router.attempt("Eastmoney K-line", lambda: router.kline(code, 90))
    flow_attempt = router.attempt("Eastmoney fund flow", lambda: router.fund_flow(code, 5))
    index_attempt = router.attempt("Shanghai index K-line", lambda: router.kline("000001", 90))

    kline_data = kline_attempt.get("data") if kline_attempt.get("ok") else None
    price = latest_price(quote_bundle, kline_data)
    entry_low, entry_high = candidate["entry_zone"]

    action = "WAIT"
    alert_level = "normal"
    reasons: list[str] = []

    if price is None:
        action = "DATA_MISSING"
        alert_level = "warning"
        reasons.append("未取得现价或最近收盘价，不能判断买点。")
    elif entry_low <= price <= entry_high:
        action = "ENTRY_ZONE_REVIEW"
        alert_level = "watch"
        reasons.append(f"价格 {price:.2f} 已进入计划买入区 {entry_low:.2f}-{entry_high:.2f}。")
        reasons.append("仍需复核大盘、板块、个股三道闸门，且必须由 Alex 确认后才能交易。")
    elif price > entry_high:
        action = "NO_CHASE"
        reasons.append(f"价格 {price:.2f} 高于买入区上沿 {entry_high:.2f}，按归澜纪律不追涨。")
    else:
        action = "BELOW_ENTRY_ZONE"
        alert_level = "watch"
        reasons.append(f"价格 {price:.2f} 低于计划买入区下沿 {entry_low:.2f}，需判断是更优买点还是破位。")

    gate_market = "UNKNOWN"
    if index_attempt.get("ok"):
        idx = index_attempt["data"]
        close = (idx.get("latest") or {}).get("close")
        ma20 = idx.get("ma20")
        ma60 = idx.get("ma60")
        if close and ma20 and ma60:
            gate_market = "PASS" if close > ma20 and ma20 >= ma60 else "BLOCK"

    return {
        "type": "candidate_watch",
        "candidate": candidate,
        "quote": quote_bundle,
        "kline": kline_attempt,
        "fund_flow": flow_attempt,
        "market_gate": gate_market,
        "decision": {
            "action": action,
            "alert_level": alert_level,
            "reasons": reasons,
            "human_confirm_required": True,
        },
    }


def render_message(check_type: str, signal: dict[str, Any]) -> str:
    candidate = signal["candidate"]
    decision = signal["decision"]
    quote = (signal.get("quote") or {}).get("quote") or {}
    price = quote.get("price")
    price_text = "未知" if price is None else f"{price:.2f}"
    reasons = "\n".join([f"- {x}" for x in decision["reasons"]])
    gate = signal.get("market_gate", "UNKNOWN")
    title_map = {
        "premarket": "盘前计划",
        "open": "开盘确认",
        "midday": "午盘检查",
        "tail": "尾盘决策",
        "close": "收盘复盘",
        "scan": "候选监控",
    }
    title = title_map.get(check_type, check_type)
    return (
        f"【归澜{title}】\n"
        f"状态：空仓，候选 {candidate['name']} {candidate['code']}\n"
        f"当前价：{price_text}\n"
        f"计划买入区：{candidate['entry_zone'][0]:.2f}-{candidate['entry_zone'][1]:.2f}\n"
        f"止损：{candidate['stop_loss']:.2f}；止盈：{candidate['take_profit_1']} / {candidate['take_profit_2']}\n"
        f"大盘闸门：{gate}\n"
        f"动作：{decision['action']}\n"
        f"{reasons}\n"
        f"纪律：不追涨；未获 Alex 确认不得交易。"
    )


def append_runtime_journal(message: str) -> None:
    JOURNAL_FILE.parent.mkdir(parents=True, exist_ok=True)
    with JOURNAL_FILE.open("a", encoding="utf-8") as f:
        f.write(f"\n\n## {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{message}\n")


def run(check_type: str, push: bool = False) -> dict[str, Any]:
    state = load_state()
    router = MarketRouter()
    signal = candidate_watch(router, state)
    signal["check_type"] = check_type
    signal["created_at"] = datetime.now().isoformat(timespec="seconds")
    message = render_message(check_type, signal)
    signal["message"] = message
    save_signal(signal)
    append_runtime_journal(message)
    push_enabled = os.environ.get("GUILAN_ENABLE_PUSH") == "1"
    if push or push_enabled:
        result = notifier_from_env().send(message)
        signal["push"] = result
        save_signal({"type": "push_result", "created_at": datetime.now().isoformat(timespec="seconds"), "result": result})
    return signal


def main() -> int:
    parser = argparse.ArgumentParser(description="Run Guilan Hermes automation")
    parser.add_argument("check_type", choices=["health", "premarket", "open", "midday", "tail", "close", "scan"])
    parser.add_argument("--push", action="store_true", help="Push the result to Telegram")
    args = parser.parse_args()

    if args.check_type == "health":
        print(dumps(MarketRouter().health_check()))
        return 0
    signal = run(args.check_type, push=args.push)
    print(signal["message"])
    return 0


if __name__ == "__main__":
    sys.exit(main())

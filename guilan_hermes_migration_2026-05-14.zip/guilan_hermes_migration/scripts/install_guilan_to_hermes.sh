#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
TARGET_DIR="${GUILAN_INSTALL_DIR:-/opt/hermes/guilan}"

if [[ "$SOURCE_DIR" == "$TARGET_DIR" ]]; then
  echo "归澜已位于 $TARGET_DIR"
else
  rm -rf "$TARGET_DIR"
  mkdir -p "$(dirname "$TARGET_DIR")"
  cp -a "$SOURCE_DIR" "$TARGET_DIR"
fi

chmod +x "$TARGET_DIR"/scripts/*.sh

echo "归澜已安装到: $TARGET_DIR"
echo
echo "下一步验证："
echo "  cd $TARGET_DIR"
echo "  scripts/check_hermes_model_env.sh"
echo "  scripts/run_guilan.sh health"
echo "  scripts/run_guilan.sh scan"

# 归澜 Hermes 迁移包

更新时间：2026-05-14

这个包把 OpenClaw 中的“归澜”从聊天型前台迁移为 Hermes 后端 Agent。目标是让归澜主动执行盘前、盘中、午盘、尾盘、收盘复盘，并通过 Telegram 推送提醒。

Zeabur/Hermes 部署步骤见 `HERMES_TELEGRAM_DEPLOY.md`。

## 当前迁移状态

- 当前持仓：空仓。
- 第一单：长电科技 600584 已清仓，合计盈利 +2555.16 元。
- 当前候选：新洁能 605111。
- 计划买入区：44~45 元。
- 止损：42.00 元。
- 止盈：47.5~48 / 50.5~52。

## 目录说明

| 目录 | 说明 |
|------|------|
| `config/` | 归澜状态与环境变量模板 |
| `knowledge/` | 给模型读取的精简知识文件 |
| `openclaw_sources/` | 从 OpenClaw 迁出的原始归澜文件备份 |
| `prompts/` | Hermes 系统提示词 |
| `src/` | Hermes 后端执行代码 |
| `scripts/` | 启动脚本与定时任务模板 |
| `logs/` | 运行后生成的信号日志 |
| `state/` | 运行后生成的实时交易日志 |

## Zeabur 模型修复

如果 Hermes 重启后又回到 OpenRouter Claude，不要在 UI 里反复切换模型。按 `HERMES_DEEPSEEK_MODEL_FIX.md`，把 DeepSeek 固化到 Zeabur 服务环境变量：

```text
DEEPSEEK_API_KEY=你的 DeepSeek 密钥
HERMES_INFERENCE_PROVIDER=deepseek
HERMES_INFERENCE_MODEL=deepseek-v4-pro
OPENAI_BASE_URL=https://api.deepseek.com
OPENAI_MODEL=deepseek-v4-pro
```

## 快速测试

```bash
cd guilan_hermes_migration
chmod +x scripts/*.sh
scripts/check_hermes_model_env.sh
scripts/run_guilan.sh health
scripts/run_guilan.sh scan
```

`health` 用来检查国信、东方财富、新浪数据源。`scan` 会按当前空仓状态检查新洁能是否进入计划买入区。

## Telegram 推送

先配置环境变量：

```bash
export GUILAN_PUSH_CHANNEL=telegram
export GUILAN_ENABLE_PUSH=1
export TELEGRAM_BOT_TOKEN=你的 Telegram Bot Token
export TELEGRAM_HOME_CHANNEL=你的 Telegram chat_id
```

然后执行：

```bash
scripts/run_guilan.sh scan --push
```

Hermes 网关提示 `No home channel is set` 时，在 Telegram 与机器人对话框里发送 `/sethome`。

## Hermes 定时任务

参考 `scripts/hermes_cron.example`：

```text
08:50 盘前计划
09:35 开盘确认
11:30 午盘检查
14:45 尾盘决策
15:15 收盘复盘
```

## 安全边界

- 本系统只生成操盘建议和提醒，不自动下单。
- 真实交易必须由 Alex 人工确认。
- API key 不写入知识库、不写入提示词、不写入代码。

## Open WebUI 的角色

Open WebUI 不再作为核心执行引擎，只保留为：

- 手动追问
- 查看知识库
- 复盘解释
- 调试 Hermes 输出

归澜的核心执行迁移到 Hermes。

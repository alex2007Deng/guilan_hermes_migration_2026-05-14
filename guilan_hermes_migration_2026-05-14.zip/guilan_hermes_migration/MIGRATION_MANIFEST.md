# 归澜迁移清单

## 已迁移

| 来源 | 目标 | 用途 |
|------|------|------|
| `~/.openclaw/skills/trading-strategy/SKILL.md` | `knowledge/归澜交易策略-v1.4.1.md` | 核心策略 |
| `~/.openclaw/workspace/memory/trading-goals.md` | `knowledge/归澜操盘目标与纪律.md` | 目标与纪律 |
| `~/.openclaw/workspace/memory/trading-journal.md` | `knowledge/归澜交易日志-当前持仓.md` | 当前持仓与候选 |
| `~/.openclaw/workspace/memory/2026-04-27-trading.md` | `knowledge/归澜历史日志-2026-04-27.md` | 历史交易 |
| `~/.openclaw/workspace/memory/2026-04-28-trading.md` | `knowledge/归澜历史日志-2026-04-28.md` | 历史交易 |
| `~/.openclaw/workspace/eastmoney_daily.py` | `openclaw_sources/scripts/eastmoney_daily.py` | 东方财富原始数据脚本 |
| `~/.openclaw/skills/trading-strategy/scripts/guilun_data.py` | `openclaw_sources/scripts/guilun_data.py` | 归澜原始数据引擎 |
| `~/.openclaw/skills/gs-stock-market-query/` | `openclaw_sources/skills/gs-stock-market-query/` | 国信行情 skill 原始备份 |
| `~/.openclaw/skills/gs-stock-financial-query/` | `openclaw_sources/skills/gs-stock-financial-query/` | 国信财务 skill 原始备份 |
| `~/.openclaw/skills/gs-economy-query/` | `openclaw_sources/skills/gs-economy-query/` | 国信宏观 skill 原始备份 |
| `~/.openclaw/skills/gs-smart-stock-picking/` | `openclaw_sources/skills/gs-smart-stock-picking/` | 国信智能选股 skill 原始备份 |
| `~/.openclaw/skills/gs-fund-compare/` | `openclaw_sources/skills/gs-fund-compare/` | 国信基金对比 skill 原始备份 |
| `~/.openclaw/skills/gs-etf-filter/` | `openclaw_sources/skills/gs-etf-filter/` | 国信 ETF 筛选 skill 原始备份 |

## 新增 Hermes 文件

| 文件 | 用途 |
|------|------|
| `config/guilan_state.json` | Hermes 运行状态：空仓、候选新洁能、风控价位 |
| `config/env.example` | 环境变量模板 |
| `prompts/guilan_hermes_system_prompt.md` | Hermes 归澜系统提示词 |
| `src/guilan_market.py` | 国信/东方财富/新浪行情路由 |
| `src/guilan_agent.py` | 归澜自动检查与信号生成 |
| `src/guilan_notifier.py` | Telegram 主动推送适配 |
| `scripts/run_guilan.sh` | 本地/Hermes 启动脚本 |
| `scripts/check_hermes_model_env.sh` | Hermes/DeepSeek 默认模型自检 |
| `scripts/install_guilan_to_hermes.sh` | 解压后安装到 `/opt/hermes/guilan` |
| `scripts/install_openclaw_skills_to_hermes.sh` | 可选：把 OpenClaw skills 原样复制到 `/opt/hermes/skills` |
| `scripts/hermes_cron.example` | 定时任务模板 |
| `HERMES_DEEPSEEK_MODEL_FIX.md` | Zeabur 重启回 Claude 的修复说明 |
| `HERMES_TELEGRAM_DEPLOY.md` | Hermes + Telegram 部署步骤 |

## 未迁移

以下内容与归澜操盘无关，未迁入 Hermes 包：

- 财识通公众号项目
- 经济学人采集
- 微信公众号自动化
- 办公助手身份
- 通用子 Agent 架构文档
- OpenClaw session 原始对话
- 密钥文件

## 当前业务状态

- 长电科技 600584：已清仓。
- 新洁能 605111：候选，等待回调 44~45。
- 当前模式：`paper_advice`，只建议，不自动下单。

## 下一步

1. 把本目录部署到 Hermes 可访问的工作目录。
2. 按 `HERMES_DEEPSEEK_MODEL_FIX.md` 固化 DeepSeek 默认模型。
3. 设置 `GS_API_KEY` 或 `S_API_KEY`。
4. 设置 Telegram 推送环境变量，并在 Telegram 中发送 `/sethome`。
5. 在 Hermes 中加载 `prompts/guilan_hermes_system_prompt.md`。
6. 配置 `scripts/hermes_cron.example` 中的五个交易日定时任务。
7. 执行 `scripts/check_hermes_model_env.sh`、`scripts/run_guilan.sh health` 和 `scripts/run_guilan.sh scan --push` 验证。
